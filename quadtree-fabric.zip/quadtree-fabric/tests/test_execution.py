"""
tests/test_execution.py

This module contains unit tests for the core execution subsystem, including
the ExecutionEngine, the registry, and the individual language executors.

To run these tests, execute from the project's root directory:
python -m unittest tests/test_execution.py
"""

import unittest
import shutil
import sys
from pathlib import Path

# Add the 'src' directory to the Python path to allow direct imports
# of our application modules for testing.
sys.path.insert(0, str(Path(__file__).parent.parent / "src"))

from quadtreefabric.execution.engine import ExecutionEngine
from quadtreefabric.data_models import ExecMeta

# --- Helper to check for compiler availability ---
C_COMPILER = shutil.which("gcc") or shutil.which("clang")
CPP_COMPILER = shutil.which("g++") or shutil.which("clang++")
JAVA_COMPILER = shutil.which("javac")


class TestExecutionEngine(unittest.TestCase):
    """
    A test suite for the ExecutionEngine and its integrated components.
    """

    @classmethod
    def setUpClass(cls):
        """
        Set up the ExecutionEngine once for all tests in this class.
        """
        cls.engine = ExecutionEngine()

    def test_01_python_execution_success(self):
        """Tests a basic, successful Python code execution."""
        code = "a = 42\nprint(a)"
        result = self.engine.execute("python", code)
        self.assertTrue(result.ok)
        self.assertEqual(result.stdout, "42\n")
        self.assertEqual(result.stderr, "")
        self.assertEqual(result.exit_code, 0)

    def test_02_python_session_state(self):
        """Tests if the Python executor maintains state between calls."""
        # First execution defines a variable
        code1 = "my_variable = 'hello from session'"
        result1 = self.engine.execute("python", code1)
        self.assertTrue(result1.ok)

        # Second execution uses the variable
        code2 = "print(my_variable)"
        result2 = self.engine.execute("python", code2)
        self.assertTrue(result2.ok)
        self.assertEqual(result2.stdout, "hello from session\n")

    def test_03_python_execution_error(self):
        """Tests the handling of a runtime error in Python."""
        code = "print(1 / 0)"
        result = self.engine.execute("python", code)
        self.assertFalse(result.ok)
        self.assertIn("ZeroDivisionError", result.stderr)
        self.assertEqual(result.exit_code, 1)

    def test_04_python_timeout(self):
        """Tests if the Python executor correctly enforces timeouts."""
        code = "import time; time.sleep(2)"
        policy = {"timeout": 1}
        result = self.engine.execute("python", code, policy)
        self.assertFalse(result.ok)
        self.assertIn("timed out", result.stderr)

    @unittest.skipIf(not C_COMPILER, "C compiler (gcc or clang) not found.")
    def test_05_c_execution_success(self):
        """Tests a successful compile-and-run cycle for C."""
        code = '#include <stdio.h>\nint main() { printf("Hello, C!"); return 0; }'
        result = self.engine.execute("c", code)
        self.assertTrue(result.ok, msg=f"C execution failed. Stderr: {result.stderr}")
        self.assertEqual(result.stdout, "Hello, C!")
        self.assertEqual(result.exit_code, 0)

    @unittest.skipIf(not C_COMPILER, "C compiler (gcc or clang) not found.")
    def test_06_c_compilation_error(self):
        """Tests the handling of a C compilation error."""
        code = '#include <stdio.h>\nint main() { printf("unterminated string); return 0; }'
        result = self.engine.execute("c", code)
        self.assertFalse(result.ok)
        self.assertIn("error:", result.stderr.lower())

    @unittest.skipIf(not CPP_COMPILER, "C++ compiler (g++ or clang++) not found.")
    def test_07_cpp_execution_success(self):
        """Tests a successful compile-and-run cycle for C++."""
        code = '#include <iostream>\nint main() { std::cout << "Hello, C++!"; return 0; }'
        result = self.engine.execute("cpp", code)
        self.assertTrue(result.ok, msg=f"C++ execution failed. Stderr: {result.stderr}")
        self.assertEqual(result.stdout, "Hello, C++!")
        self.assertEqual(result.exit_code, 0)

    @unittest.skipIf(not JAVA_COMPILER, "Java compiler (javac) not found.")
    def test_08_java_execution_success(self):
        """Tests a successful compile-and-run cycle for Java."""
        code = 'public class Test { public static void main(String[] args) { System.out.print("Hello, Java!"); } }'
        result = self.engine.execute("java", code)
        self.assertTrue(result.ok, msg=f"Java execution failed. Stderr: {result.stderr}")
        self.assertEqual(result.stdout, "Hello, Java!")
        self.assertEqual(result.exit_code, 0)
        
    def test_09_unknown_language(self):
        """Tests the engine's response to a request for an unregistered language."""
        code = "print('this should fail')"
        result = self.engine.execute("fortran", code)
        self.assertFalse(result.ok)
        self.assertIn("No executor registered for language: 'fortran'", result.stderr)


if __name__ == "__main__":
    unittest.main()
