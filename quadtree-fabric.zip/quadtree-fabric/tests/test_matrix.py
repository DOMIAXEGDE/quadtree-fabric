"""
tests/test_matrix.py

This module contains unit tests for the MatrixHandler class, which is responsible
for all core data manipulation and state management of the quadtree contexts.

To run these tests, execute from the project's root directory:
python -m unittest tests/test_matrix.py
"""

import unittest
import sys
from pathlib import Path

# Add the 'src' directory to the Python path to allow direct imports
# of our application modules for testing.
sys.path.insert(0, str(Path(__file__).parent.parent / "src"))

from quadtreefabric.core.matrix_handler import MatrixHandler
from quadtreefabric.data_models import CellPayload


class TestMatrixHandler(unittest.TestCase):
    """
    A test suite for the MatrixHandler class.
    """

    def setUp(self):
        """
        Set up a new MatrixHandler instance before each test.
        """
        self.handler = MatrixHandler()

    def test_01_create_new_context(self):
        """Tests the successful creation of a new, empty context."""
        context_id = "test_context"
        size = 800
        max_depth = 3
        
        matrix = self.handler.create_new_context(context_id, size, max_depth)
        
        # Verify the context was created and set as current
        self.assertIn(context_id, self.handler.contexts)
        self.assertEqual(self.handler.current_context_id, context_id)
        
        # Verify matrix properties
        self.assertEqual(matrix.quadtree_size, size)
        self.assertEqual(matrix.max_depth, max_depth)
        self.assertEqual(len(matrix.layers), max_depth + 1)
        self.assertEqual(len(matrix.payload_pool), 0)
        
        # Verify layer structure
        for d in range(max_depth + 1):
            layer_size = 1 << d
            self.assertEqual(matrix.layers[d].size, layer_size)
            self.assertEqual(len(matrix.layers[d].nodes), layer_size * layer_size)

    def test_02_create_duplicate_context_fails(self):
        """Tests that creating a context with a duplicate ID raises an error."""
        context_id = "duplicate_id"
        self.handler.create_new_context(context_id, 400, 2)
        
        with self.assertRaises(ValueError):
            self.handler.create_new_context(context_id, 400, 2)

    def test_03_set_and_get_payload(self):
        """Tests setting and retrieving a CellPayload."""
        self.handler.create_new_context("payload_test", 400, 2)
        cell_coords = (1, 2) # Depth 1, Index 2
        
        payload = CellPayload(
            type="code",
            content={"language": "python", "code": "print('test')"}
        )
        
        # Test setting the payload
        set_success = self.handler.set_cell_payload(cell_coords, payload)
        self.assertTrue(set_success)
        
        # Test retrieving the payload
        retrieved_payload = self.handler.get_cell_payload(cell_coords)
        self.assertIsNotNone(retrieved_payload)
        self.assertEqual(retrieved_payload, payload)
        self.assertEqual(retrieved_payload.content["code"], "print('test')")

    def test_04_subdivide_cell(self):
        """Tests the logic for cell subdivision, including payload propagation."""
        self.handler.create_new_context("subdivide_test", 400, 2)
        matrix = self.handler.get_current_context()
        
        parent_coords = (0, 0) # Top-level cell
        parent_depth, parent_index = parent_coords
        
        # Set parent properties
        parent_color = 0xFF0000 # Red
        matrix.layers[parent_depth].nodes[parent_index] = parent_color
        parent_payload = CellPayload(type="text", content={"text": "propagated"})
        self.handler.set_cell_payload(parent_coords, parent_payload)
        
        # Perform subdivision
        subdivide_success = self.handler.subdivide_cell(parent_coords)
        self.assertTrue(subdivide_success)
        
        # Verify children properties
        child_depth = parent_depth + 1
        child_layer = matrix.layers[child_depth]
        
        # The four children of cell (0,0) are (1,0), (1,1), (1,2), (1,3)
        for child_index in range(4):
            # Check color propagation
            self.assertEqual(child_layer.nodes[child_index], parent_color)
            
            # Check payload propagation
            child_payload = self.handler.get_cell_payload((child_depth, child_index))
            self.assertIsNotNone(child_payload)
            self.assertEqual(child_payload.content["text"], "propagated")

    def test_05_subdivide_at_max_depth_fails(self):
        """Tests that subdivision fails at the maximum allowed depth."""
        max_depth = 2
        self.handler.create_new_context("max_depth_test", 400, max_depth)
        
        # Attempt to subdivide a cell at the max depth
        cell_at_max_depth = (max_depth, 0)
        subdivide_success = self.handler.subdivide_cell(cell_at_max_depth)
        self.assertFalse(subdivide_success)


if __name__ == "__main__":
    unittest.main()
