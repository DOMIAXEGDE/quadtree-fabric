"""
tests/test_io.py

This module contains unit tests for the IOHandler class, which is responsible
for all file serialization and deserialization logic.

To run these tests, execute from the project's root directory:
python -m unittest tests/test_io.py
"""

import unittest
import sys
import tempfile
from pathlib import Path

# Add the 'src' directory to the Python path to allow direct imports
# of our application modules for testing.
sys.path.insert(0, str(Path(__file__).parent.parent / "src"))

from quadtreefabric.core.io_handler import IOHandler
from quadtreefabric.data_models import Matrix, Layer, CellPayload, ExecMeta


class TestIOHandler(unittest.TestCase):
    """
    A test suite for the IOHandler class.
    """

    def setUp(self):
        """
        Set up a temporary directory for file operations before each test.
        """
        self.temp_dir = tempfile.TemporaryDirectory()
        self.io_handler = IOHandler()

    def tearDown(self):
        """
        Clean up the temporary directory after each test.
        """
        self.temp_dir.cleanup()

    def test_01_save_and_load_matrix_roundtrip(self):
        """
        Tests that a complex Matrix object can be saved to JSON and then
        loaded back, perfectly preserving its structure and data.
        """
        # 1. Create a complex Matrix object to be serialized.
        exec_meta = ExecMeta(
            ok=True,
            stdout="Success!",
            wall_ms=123.45,
            exit_code=0
        )
        payload = CellPayload(
            type="code",
            content={"language": "python", "code": "x=1"},
            last_run_meta=exec_meta
        )
        original_matrix = Matrix(
            quadtree_size=600,
            max_depth=2,
            version=2,
            layers=[Layer(size=1, nodes=[0]), Layer(size=2, nodes=[1, 2, 3, 4])],
            payload_pool={"1:2": payload}
        )
        
        test_filepath = Path(self.temp_dir.name) / "test_matrix.json"

        # 2. Save the matrix to the temporary file.
        save_success = self.io_handler.save_matrix_to_json(original_matrix, test_filepath)
        self.assertTrue(save_success)
        self.assertTrue(test_filepath.exists())

        # 3. Load the matrix back from the file.
        loaded_matrix = self.io_handler.load_matrix_from_json(test_filepath)

        # 4. Assert that the loaded matrix is identical to the original.
        self.assertIsNotNone(loaded_matrix)
        
        # Compare top-level attributes
        self.assertEqual(original_matrix.quadtree_size, loaded_matrix.quadtree_size)
        self.assertEqual(original_matrix.max_depth, loaded_matrix.max_depth)
        self.assertEqual(original_matrix.version, loaded_matrix.version)
        
        # Compare layer structure
        self.assertEqual(len(original_matrix.layers), len(loaded_matrix.layers))
        self.assertEqual(original_matrix.layers[1].nodes, loaded_matrix.layers[1].nodes)
        
        # Compare payload pool, including the nested ExecMeta dataclass
        self.assertIn("1:2", loaded_matrix.payload_pool)
        loaded_payload = loaded_matrix.payload_pool["1:2"]
        self.assertEqual(original_matrix.payload_pool["1:2"].type, loaded_payload.type)
        self.assertEqual(original_matrix.payload_pool["1:2"].content, loaded_payload.content)
        
        self.assertIsNotNone(loaded_payload.last_run_meta)
        self.assertEqual(original_matrix.payload_pool["1:2"].last_run_meta.stdout, loaded_payload.last_run_meta.stdout)
        self.assertEqual(original_matrix.payload_pool["1:2"].last_run_meta.wall_ms, loaded_payload.last_run_meta.wall_ms)

    def test_02_load_invalid_json_fails_gracefully(self):
        """
        Tests that the IOHandler returns None when attempting to load a
        malformed or invalid JSON file, without crashing.
        """
        invalid_json_content = '{"quadtree_size": 400, "max_depth": 2, "layers": [}'
        test_filepath = Path(self.temp_dir.name) / "invalid.json"
        test_filepath.write_text(invalid_json_content)
        
        loaded_matrix = self.io_handler.load_matrix_from_json(test_filepath)
        self.assertIsNone(loaded_matrix)

    def test_03_load_missing_keys_fails_gracefully(self):
        """
        Tests that the IOHandler returns None when a required key is missing
        from the JSON file.
        """
        json_with_missing_key = '{"quadtree_size": 400, "layers": []}' # Missing 'max_depth'
        test_filepath = Path(self.temp_dir.name) / "missing_key.json"
        test_filepath.write_text(json_with_missing_key)
        
        loaded_matrix = self.io_handler.load_matrix_from_json(test_filepath)
        self.assertIsNone(loaded_matrix)


if __name__ == "__main__":
    unittest.main()
