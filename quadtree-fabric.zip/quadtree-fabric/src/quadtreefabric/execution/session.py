"""
execution/session.py

This module defines the SessionManager and ExecutionSession classes, which are
responsible for managing the persistent state of interpreted language executors.
"""

from __future__ import annotations
from typing import Any, Dict, Optional, TYPE_CHECKING

if TYPE_CHECKING:
    from .executors._base import SessionLifecycle


class ExecutionSession:
    """
    Manages the state and lifecycle for a single instance of a stateful language.

    This class acts as a container for the session's global variables and
    provides a direct interface to the lifecycle methods (reset, snapshot,
    restore) provided by the language's executor plugin.
    """

    def __init__(self, lifecycle_handler: SessionLifecycle):
        """
        Initializes a new execution session.

        Args:
            lifecycle_handler: The object implementing the SessionLifecycle
                protocol, provided by the executor plugin.
        """
        # The dictionary that will hold the state (variables, functions, etc.)
        # of the programming environment for this session.
        self.globals: Dict[str, Any] = {}
        self.lifecycle_handler = lifecycle_handler

    def reset(self) -> None:
        """Resets the session to a clean state."""
        if hasattr(self.lifecycle_handler, 'reset'):
            self.lifecycle_handler.reset()
        # As a fallback or primary mechanism, we clear our own globals dict.
        self.globals.clear()
        print(f"[Session] Session state has been reset.")

    def snapshot(self) -> Optional[bytes]:
        """
        Creates a snapshot of the session's current state.

        Returns:
            A byte string representing the serialized state, or None if the
            handler does not support snapshotting.
        """
        if hasattr(self.lifecycle_handler, 'snapshot'):
            return self.lifecycle_handler.snapshot()
        return None

    def restore(self, snapshot_data: bytes) -> None:
        """
        Restores the session's state from a snapshot.

        Args:
            snapshot_data: The data from a previously created snapshot.
        """
        if hasattr(self.lifecycle_handler, 'restore'):
            self.lifecycle_handler.restore(snapshot_data)


class SessionManager:
    """
    Manages a collection of ExecutionSession objects, one for each stateful
    language.

    This class is the main entry point for the rest of the application to
    interact with persistent execution environments. It ensures that each
    language that supports a session has its own isolated state.
    """

    def __init__(self):
        # A dictionary mapping a language name to its active ExecutionSession.
        self._sessions: Dict[str, ExecutionSession] = {}

    def get_or_create_session(
        self,
        lang: str,
        lifecycle_handler: Optional[SessionLifecycle]
    ) -> Optional[ExecutionSession]:
        """
        Retrieves an existing session for a language or creates a new one.

        If a session for the given language already exists, it is returned.
        If not, a new session is created, but only if the language's executor
        provided a valid lifecycle handler.

        Args:
            lang: The name of the language.
            lifecycle_handler: The lifecycle handler object from the registry.

        Returns:
            The ExecutionSession for the language, or None if the language is
            stateless (i.e., has no lifecycle handler).
        """
        lang_lower = lang.lower()
        if lang_lower in self._sessions:
            return self._sessions[lang_lower]

        if lifecycle_handler:
            print(f"[SessionManager] Creating new persistent session for '{lang_lower}'.")
            session = ExecutionSession(lifecycle_handler)
            self._sessions[lang_lower] = session
            return session

        # This language is stateless, so no session is created.
        return None

    def get_session(self, lang: str) -> Optional[ExecutionSession]:
        """
        Retrieves the active session for a given language.

        Args:
            lang: The name of the language.

        Returns:
            The active ExecutionSession, or None if no session exists for
            that language.
        """
        return self._sessions.get(lang.lower())
