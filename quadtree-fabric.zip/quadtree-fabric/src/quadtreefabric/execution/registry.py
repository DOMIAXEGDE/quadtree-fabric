"""
execution/registry.py

This module defines the ExecutorRegistry, the central component responsible for
discovering, loading, and managing all language executors within the Quadtree
Fabric application. It supports loading executors from both the local, built-in
`executors` directory and from installed third-party packages via entry points.
"""

from __future__ import annotations
import importlib
import importlib.metadata
import sys
from pathlib import Path
from typing import Dict, List, Optional, Tuple, TYPE_CHECKING

from .constants import ENTRYPOINT_GROUP

if TYPE_CHECKING:
    from .executors._base import Executor, SessionLifecycle


class ExecutorRegistry:
    """
    A global registry for discovering and managing language executors.

    This class provides a centralized point of access to all available language
    handlers, abstracting away the details of how and where they are located.
    It also manages session lifecycle handlers for stateful languages.
    """

    def __init__(self):
        # A dictionary mapping a language name (e.g., "python") to its
        # executor function and optional lifecycle handler.
        self._executors: Dict[str, Tuple[Executor, Optional[SessionLifecycle]]] = {}
        self.discover_plugins()

    def register(
        self,
        lang: str,
        executor: Executor,
        lifecycle_handler: Optional[SessionLifecycle] = None
    ) -> None:
        """
        Registers a new language executor with the system.

        This method is called by the `register` function within each plugin
        module during the discovery process.

        Args:
            lang: The name of the language (e.g., "python", "c").
            executor: The callable that conforms to the Executor protocol.
            lifecycle_handler: An optional object that conforms to the
                SessionLifecycle protocol for stateful languages.
        """
        lang_lower = lang.lower()
        if lang_lower in self._executors:
            print(f"[Registry] Warning: Overwriting existing executor for language '{lang_lower}'.")
        self._executors[lang_lower] = (executor, lifecycle_handler)
        print(f"[Registry] Registered executor for language: {lang_lower}")

    def get_executor(self, lang: str) -> Optional[Tuple[Executor, Optional[SessionLifecycle]]]:
        """
        Retrieves the executor and lifecycle handler for a given language.

        Args:
            lang: The name of the language.

        Returns:
            A tuple containing the executor and its lifecycle handler, or None
            if the language is not registered.
        """
        return self._executors.get(lang.lower())

    def list_languages(self) -> List[str]:
        """Returns a sorted list of all registered language names."""
        return sorted(self._executors.keys())

    def discover_plugins(self) -> None:
        """
        Discovers all available plugins from both local files and installed
        entry points. This method is called upon initialization.
        """
        print("[Registry] Starting plugin discovery...")
        self._discover_local_plugins()
        self._discover_entry_point_plugins()
        print(f"[Registry] Discovery complete. {len(self._executors)} languages available.")

    def _discover_local_plugins(self) -> None:
        """
        Scans the built-in `executors` directory for local plugins.
        """
        local_plugins_dir = Path(__file__).parent / "executors"
        if not local_plugins_dir.is_dir():
            return

        print(f"[Registry] Scanning local directory: {local_plugins_dir}")
        for file in local_plugins_dir.glob("*.py"):
            if file.stem.startswith(("_", ".")):
                continue

            module_name = f"quadtreefabric.execution.executors.{file.stem}"
            try:
                spec = importlib.util.spec_from_file_location(module_name, file)
                if spec and spec.loader:
                    mod = importlib.util.module_from_spec(spec)
                    # Add to sys.modules before execution to allow relative imports
                    sys.modules[module_name] = mod
                    spec.loader.exec_module(mod)
                    if hasattr(mod, "register"):
                        mod.register(self)
            except Exception as e:
                print(f"[Registry] Failed to load local plugin {file.name}: {e}")

    def _discover_entry_point_plugins(self) -> None:
        """
        Discovers plugins installed as packages via the setuptools entry point.
        """
        print(f"[Registry] Scanning for installed entry point plugins in group '{ENTRYPOINT_GROUP}'...")
        try:
            entry_points = importlib.metadata.entry_points(group=ENTRYPOINT_GROUP)
            for entry_point in entry_points:
                try:
                    plugin_module = entry_point.load()
                    if hasattr(plugin_module, "register"):
                        print(f"[Registry] Loading entry point plugin: {entry_point.name}")
                        plugin_module.register(self)
                except Exception as e:
                    print(f"[Registry] Failed to load entry point plugin '{entry_point.name}': {e}")
        except Exception as e:
            # This can happen on some Python installations or environments.
            print(f"[Registry] Could not scan for entry points: {e}")
