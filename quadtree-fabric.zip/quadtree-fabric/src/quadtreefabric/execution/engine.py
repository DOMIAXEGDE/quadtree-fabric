"""
execution/engine.py

This module defines the ExecutionEngine, the primary public interface for the
entire code execution subsystem. It coordinates the registry, session manager,
and individual executors to provide a unified, high-level API.
"""

from __future__ import annotations
from typing import Any, Dict, List, Optional, TYPE_CHECKING

from ..data_models import ExecMeta
from .registry import ExecutorRegistry
from .session import SessionManager

if TYPE_CHECKING:
    from .session import ExecutionSession


class ExecutionEngine:
    """
    The main coordinator for all code execution within the application.

    This class acts as a singleton facade, providing a simple interface to the
    more complex underlying components like the registry and session manager.
    It is the sole entry point for the UI and core logic layers to run code.
    """

    def __init__(self):
        """Initializes the execution engine and its subordinate components."""
        print("[Engine] Initializing execution subsystem...")
        self.registry = ExecutorRegistry()
        self.session_manager = SessionManager()
        print("[Engine] Execution subsystem ready.")

    def execute(self, lang: str, code: str, policy: Optional[Dict[str, Any]] = None) -> ExecMeta:
        """
        Executes a block of code for a given language.

        This is the primary method used by the application to run code. It
        handles finding the executor, managing the session, and returning a
        structured result.

        Args:
            lang: The name of the language to execute (e.g., "python").
            code: The source code string to run.
            policy: An optional dictionary of execution policies (e.g., timeout).

        Returns:
            An ExecMeta object containing the results of the execution.
        """
        policy = policy or {}
        executor_info = self.registry.get_executor(lang)

        if not executor_info:
            return ExecMeta(ok=False, stderr=f"No executor registered for language: '{lang}'")

        executor, lifecycle_handler = executor_info
        session = self.session_manager.get_or_create_session(lang, lifecycle_handler)

        # For stateful languages, pass the session's globals dictionary.
        # For stateless languages, session will be None, so we pass None.
        session_globals = session.globals if session else None

        return executor(code, session_globals, policy)

    def get_session(self, lang: str) -> Optional[ExecutionSession]:
        """
        Retrieves the active session for a given language, if one exists.

        Args:
            lang: The name of the language.

        Returns:
            The ExecutionSession object or None if the language is stateless.
        """
        return self.session_manager.get_session(lang)

    def list_available_languages(self) -> List[str]:
        """
        Returns a list of all currently registered and available languages.
        """
        return self.registry.list_languages()

# --- Singleton Instance ---
# We create a single, global instance of the ExecutionEngine that the rest of
# the application will import and use. This ensures that the registry and
# session manager are initialized only once.

ENGINE = ExecutionEngine()
