"""
execution/executors/python_exec.py

This module provides a robust, stateful executor for Python 3 code.

It runs code in an isolated process to prevent blocking the main UI thread
and to ensure safe termination of long-running or misbehaving scripts.
It fully implements the SessionLifecycle protocol, allowing users to snapshot,
restore, and reset the Python execution environment.
"""

from __future__ import annotations
import io
import time
import traceback
from contextlib import redirect_stdout, redirect_stderr
from multiprocessing import Process, Queue
from typing import Any, Dict, Optional, TYPE_CHECKING

# dill is a more powerful serialization library than pickle, capable of
# handling a wider range of Python objects. It's recommended for robust
# session snapshotting. We fall back to pickle if dill is not available.
try:
    import dill
    SERIALIZER = dill
except ImportError:
    import pickle
    SERIALIZER = pickle

from ...data_models import ExecMeta
from ..constants import TIMEOUT_DEFAULT

if TYPE_CHECKING:
    from ..registry import ExecutorRegistry


class PythonExecutor:
    """
    A class that encapsulates the execution and state management for a
    persistent Python session.
    """
    def __init__(self):
        self.session_globals: Dict[str, Any] = {}

    def __call__(
        self,
        code: str,
        session_globals: Optional[Dict[str, Any]],
        policy: Dict[str, Any]
    ) -> "ExecMeta":
        """
        Executes the Python code in a separate, isolated process.

        This method conforms to the Executor protocol. It spawns a worker
        process to run the code, captures its output, and enforces timeouts.
        """
        start_time = time.perf_counter()
        # If session_globals is provided, it means we are in a stateful session
        # managed by the ExecutorRegistry. We use the instance's state.
        if session_globals is not None:
            current_globals = self.session_globals
        else:
            # Otherwise, it's a stateless execution. Use a clean dict.
            current_globals = {}

        # Use a multiprocessing queue to get the result back from the worker.
        result_queue: "Queue[Dict[str, Any]]" = Queue()
        timeout = policy.get("timeout", TIMEOUT_DEFAULT)

        # The target function to be run in the separate process.
        process = Process(
            target=self._execute_target,
            args=(code, current_globals, result_queue)
        )
        process.start()
        process.join(timeout)

        if process.is_alive():
            process.terminate()
            process.join()
            return ExecMeta(
                ok=False,
                stderr=f"Execution timed out after {timeout} seconds.",
                wall_ms=(time.perf_counter() - start_time) * 1000,
                exit_code= -1
            )

        try:
            result = result_queue.get_nowait()
            # Update the session state with the potentially modified globals
            self.session_globals = result.get("globals", self.session_globals)

            return ExecMeta(
                ok=result.get("ok", False),
                stdout=result.get("stdout", ""),
                stderr=result.get("stderr", ""),
                exit_code=result.get("exit_code", 1),
                wall_ms=(time.perf_counter() - start_time) * 1000,
                session_changed=result.get("session_changed", False)
            )
        except Exception as e:
            return ExecMeta(
                ok=False,
                stderr=f"Failed to retrieve execution result: {e}",
                wall_ms=(time.perf_counter() - start_time) * 1000,
                exit_code= -1
            )

    def _execute_target(
        self,
        code: str,
        globals_dict: Dict[str, Any],
        q: "Queue[Dict[str, Any]]"
    ):
        """The actual code execution logic that runs in the child process."""
        stdout_io = io.StringIO()
        stderr_io = io.StringIO()
        ok = False
        exit_code = 0

        try:
            with redirect_stdout(stdout_io), redirect_stderr(stderr_io):
                exec(code, globals_dict)
            ok = True
        except Exception:
            exit_code = 1
            # Capture the full traceback in stderr for better debugging.
            stderr_io.write(traceback.format_exc())
        finally:
            q.put({
                "ok": ok,
                "stdout": stdout_io.getvalue(),
                "stderr": stderr_io.getvalue(),
                "exit_code": exit_code,
                "globals": globals_dict,
                "session_changed": True,
            })

    # --- SessionLifecycle Methods ---

    def reset(self) -> None:
        """Resets the session by clearing the globals dictionary."""
        self.session_globals.clear()

    def snapshot(self) -> bytes:
        """Serializes the session's globals dictionary."""
        return SERIALIZER.dumps(self.session_globals)

    def restore(self, snapshot_data: bytes) -> None:
        """Restores the session's globals from a snapshot."""
        self.session_globals = SERIALIZER.loads(snapshot_data)


def register(registry: "ExecutorRegistry") -> None:
    """
    Registers the Python executor and its session lifecycle methods with the
    central registry.
    """
    python_executor_instance = PythonExecutor()
    registry.register(
        lang="python",
        executor=python_executor_instance,
        lifecycle_handler=python_executor_instance
    )
