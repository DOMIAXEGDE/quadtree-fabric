"""
execution/executors/c_exec.py

This module provides a robust, stateless executor for C code (C11 standard).

It follows a secure compile-and-run lifecycle:
1. A C compiler (gcc or clang) is located on the system.
2. The provided C source code is written to a temporary file within a
   sandboxed, temporary directory.
3. The code is compiled into an executable. Compilation errors are captured.
4. If compilation succeeds, the executable is run. Runtime output and errors
   are captured.
5. The temporary directory and all its contents are automatically cleaned up.

This executor is stateless and does not implement the SessionLifecycle protocol.
"""

from __future__ import annotations
import os
import shutil
import subprocess
import tempfile
import time
from pathlib import Path
from typing import Any, Dict, Iterable, Optional, TYPE_CHECKING

from ...data_models import ExecMeta
from ..constants import TIMEOUT_DEFAULT

if TYPE_CHECKING:
    from ..registry import ExecutorRegistry


def _find_compiler(progs: Iterable[str]) -> Optional[str]:
    """Finds the first available program in a list of executables."""
    for p in progs:
        exe = shutil.which(p)
        if exe:
            return exe
    return None


def c_executor(
    code: str,
    session_globals: Optional[Dict[str, Any]],
    policy: Dict[str, Any]
) -> "ExecMeta":
    """
    Compiles and runs C code in an isolated, temporary environment.

    This function conforms to the Executor protocol. Since C is a compiled,
    stateless language in this context, the `session_globals` argument is
    ignored.
    """
    start_time = time.perf_counter()
    timeout = policy.get("timeout", TIMEOUT_DEFAULT)

    compiler = _find_compiler(("gcc", "clang"))
    if not compiler:
        return ExecMeta(
            ok=False,
            stderr="No C compiler found (gcc or clang). Please ensure one is installed and in your system's PATH.",
            exit_code=-1,
            wall_ms=(time.perf_counter() - start_time) * 1000,
        )

    try:
        with tempfile.TemporaryDirectory(prefix="c_exec_") as td:
            td_path = Path(td)
            src_file = td_path / "main.c"
            exe_file = td_path / ("main.exe" if os.name == "nt" else "main.out")
            src_file.write_text(code, encoding="utf-8")

            # --- Compilation Step ---
            compile_cmd = [compiler, "-std=c11", "-O2", "-pipe", str(src_file), "-o", str(exe_file)]
            try:
                comp_proc = subprocess.run(
                    compile_cmd,
                    text=True,
                    capture_output=True,
                    timeout=timeout
                )
            except subprocess.TimeoutExpired:
                return ExecMeta(
                    ok=False,
                    stderr=f"Compilation timed out after {timeout} seconds.",
                    exit_code=-1,
                    wall_ms=(time.perf_counter() - start_time) * 1000,
                )

            if comp_proc.returncode != 0:
                return ExecMeta(
                    ok=False,
                    stdout=comp_proc.stdout,
                    stderr=f"Compilation failed with exit code {comp_proc.returncode}:\n{comp_proc.stderr}",
                    exit_code=comp_proc.returncode,
                    wall_ms=(time.perf_counter() - start_time) * 1000,
                )

            # --- Execution Step ---
            try:
                run_proc = subprocess.run(
                    [str(exe_file)],
                    text=True,
                    capture_output=True,
                    timeout=timeout
                )
            except subprocess.TimeoutExpired:
                return ExecMeta(
                    ok=False,
                    stderr=f"Execution timed out after {timeout} seconds.",
                    exit_code=-1,
                    wall_ms=(time.perf_counter() - start_time) * 1000,
                )

            return ExecMeta(
                ok=run_proc.returncode == 0,
                stdout=run_proc.stdout,
                stderr=run_proc.stderr,
                exit_code=run_proc.returncode,
                wall_ms=(time.perf_counter() - start_time) * 1000,
            )

    except Exception as e:
        return ExecMeta(
            ok=False,
            stderr=f"An unexpected error occurred during the C execution lifecycle: {e}",
            exit_code=-1,
            wall_ms=(time.perf_counter() - start_time) * 1000,
        )


def register(registry: "ExecutorRegistry") -> None:
    """
    Registers the stateless C executor with the central registry.
    """
    registry.register(
        lang="c",
        executor=c_executor,
        lifecycle_handler=None  # C is stateless, so no lifecycle methods.
    )
