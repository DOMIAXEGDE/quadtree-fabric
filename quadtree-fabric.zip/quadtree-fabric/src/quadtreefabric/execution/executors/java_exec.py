"""
execution/executors/java_exec.py

This module provides a robust, stateless executor for Java code.

It follows a secure compile-and-run lifecycle:
1.  Locates the Java compiler (javac) and runtime (java) on the system.
2.  Intelligently parses the source code to find the public main class name.
3.  Writes the source code to a correctly named .java file in a sandboxed,
    temporary directory.
4.  Compiles the source code. Compilation errors are captured.
5.  If compilation succeeds, the main class is executed. Runtime output and
    errors are captured.
6.  The temporary directory and all its contents are automatically cleaned up.

This executor is stateless and does not implement the SessionLifecycle protocol.
"""

from __future__ import annotations
import re
import shutil
import subprocess
import tempfile
import time
from pathlib import Path
from typing import Any, Dict, Iterable, Optional, TYPE_CHECKING

from ...data_models import ExecMeta
from ..constants import TIMEOUT_DEFAULT

if TYPE_CHECKING:
    from ..registry import ExecutorRegistry


def _find_executable(progs: Iterable[str]) -> Optional[str]:
    """Finds the first available program in a list of executables."""
    for p in progs:
        exe = shutil.which(p)
        if exe:
            return exe
    return None


def _find_main_class(code: str) -> Optional[str]:
    """
    Finds the main class name in a Java source string.
    It prioritizes finding a public class that contains the main method.
    """
    # Regex to find a public class containing a public static void main method.
    # This is a more robust pattern to correctly identify the entry point.
    pattern = re.compile(
        r"public\s+class\s+([a-zA-Z_][a-zA-Z0-9_]*)\s*\{"
        r"(?:[^{}]|\{(?:[^{}]|\{[^{}]*\})*\})*?"
        r"public\s+static\s+void\s+main\s*\(\s*String\s*\[\s*\]\s*\w+\s*\)"
    )
    match = pattern.search(code)
    if match:
        return match.group(1)

    # If the above fails, fall back to finding the first public class declared.
    fallback_match = re.search(r"public\s+class\s+([a-zA-Z_][a-zA-Z0-9_]*)", code)
    if fallback_match:
        return fallback_match.group(1)

    return None


def java_executor(
    code: str,
    session_globals: Optional[Dict[str, Any]],
    policy: Dict[str, Any]
) -> "ExecMeta":
    """
    Compiles and runs Java code in an isolated, temporary environment.

    This function conforms to the Executor protocol. Since Java is stateless
    in this context, the `session_globals` argument is ignored.
    """
    start_time = time.perf_counter()
    timeout = policy.get("timeout", TIMEOUT_DEFAULT)

    javac = _find_executable(["javac"])
    if not javac:
        return ExecMeta(
            ok=False,
            stderr="Java compiler 'javac' not found. Please ensure the JDK is installed and in your system's PATH.",
            exit_code=-1,
            wall_ms=(time.perf_counter() - start_time) * 1000,
        )

    java = _find_executable(["java"])
    if not java:
        return ExecMeta(
            ok=False,
            stderr="Java runtime 'java' not found. Please ensure the JRE or JDK is installed and in your system's PATH.",
            exit_code=-1,
            wall_ms=(time.perf_counter() - start_time) * 1000,
        )

    main_class = _find_main_class(code)
    if not main_class:
        return ExecMeta(
            ok=False,
            stderr="Could not find a public main class. Ensure your code has a class like 'public class MyClass { public static void main(String[] args) { ... } }'",
            exit_code=-1,
            wall_ms=(time.perf_counter() - start_time) * 1000,
        )

    try:
        with tempfile.TemporaryDirectory(prefix="java_exec_") as td:
            td_path = Path(td)
            src_file = td_path / f"{main_class}.java"
            src_file.write_text(code, encoding="utf-8")

            # --- Compilation Step ---
            compile_cmd = [javac, str(src_file)]
            try:
                comp_proc = subprocess.run(
                    compile_cmd,
                    text=True,
                    capture_output=True,
                    timeout=timeout,
                    cwd=td_path
                )
            except subprocess.TimeoutExpired:
                return ExecMeta(ok=False, stderr=f"Java compilation timed out after {timeout} seconds.", exit_code=-1, wall_ms=(time.perf_counter() - start_time) * 1000)

            if comp_proc.returncode != 0:
                return ExecMeta(ok=False, stdout=comp_proc.stdout, stderr=f"Compilation failed:\n{comp_proc.stderr}", exit_code=comp_proc.returncode, wall_ms=(time.perf_counter() - start_time) * 1000)

            # --- Execution Step ---
            run_cmd = [java, main_class]
            try:
                run_proc = subprocess.run(
                    run_cmd,
                    text=True,
                    capture_output=True,
                    timeout=timeout,
                    cwd=td_path
                )
            except subprocess.TimeoutExpired:
                return ExecMeta(ok=False, stderr=f"Java execution timed out after {timeout} seconds.", exit_code=-1, wall_ms=(time.perf_counter() - start_time) * 1000)

            return ExecMeta(
                ok=run_proc.returncode == 0,
                stdout=run_proc.stdout,
                stderr=run_proc.stderr,
                exit_code=run_proc.returncode,
                wall_ms=(time.perf_counter() - start_time) * 1000,
            )

    except Exception as e:
        return ExecMeta(ok=False, stderr=f"An unexpected error occurred during the Java execution lifecycle: {e}", exit_code=-1, wall_ms=(time.perf_counter() - start_time) * 1000)


def register(registry: "ExecutorRegistry") -> None:
    """
    Registers the stateless Java executor with the central registry.
    """
    registry.register(
        lang="java",
        executor=java_executor,
        lifecycle_handler=None  # Java is stateless, so no lifecycle methods.
    )
