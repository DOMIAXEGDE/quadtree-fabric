"""
execution/constants.py

This module defines global constants for the execution subsystem. These values
are used to configure the behavior of the execution engine, the executor
registry, and individual language plugins.
"""

from multiprocessing import Queue
from typing import Any

# --- Execution Engine Configuration ---

# Default timeout in seconds for code execution in any language.
# This can be overridden on a per-cell basis via policy.
TIMEOUT_DEFAULT: int = 5

# --- Plugin Discovery ---

# The official setuptools entry point group for discovering installed
# Quadtree Fabric language executors. Any package that wants to provide a
# language plugin must register it under this group name.
ENTRYPOINT_GROUP: str = "quadtreefabric.executors"

# --- Inter-Process Communication ---

# A multiprocessing-safe queue for sending status updates from the
# isolated execution engine back to the main UI thread. This allows for
# real-time, non-blocking logging of events like 'start', 'log', 'artifact',
# and 'done'.
STATUS_Q: "Queue[Dict[str, Any]]" = Queue()
