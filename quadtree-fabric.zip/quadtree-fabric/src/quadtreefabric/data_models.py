"""
data_models.py

This module defines the core data structures for the Quadtree Fabric application.
Centralizing these models ensures a consistent and predictable data shape across
the entire system, from the UI to the execution engine to the file I/O handlers.
"""

from __future__ import annotations
from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional

# --- Execution Engine Models ---

@dataclass(slots=True)
class ExecMeta:
    """
    A structured container for the results of a code execution.
    This replaces the simple (bool, str) tuple, providing rich, inspectable
    data about what happened during a run.
    """
    ok: bool = False
    stdout: str = ""
    stderr: str = ""
    exit_code: int = 0
    wall_ms: float = 0.0
    artifacts: Dict[str, str] = field(default_factory=dict)
    diagnostics: List[Dict[str, Any]] = field(default_factory=list)
    session_changed: bool = False
    extras: Dict[str, Any] = field(default_factory=dict)


# --- Quadtree Data Models ---

@dataclass(slots=True)
class CellPayload:
    """
    Represents the content and metadata stored within a single quadtree cell.
    This model supports different types of content (code, text, images) and
    stores execution policies and results.
    """
    type: str  # "code", "text", or "image"
    content: Dict[str, Any] = field(default_factory=dict)

    # --- Dataflow and Dependency ---
    inputs: List[str] = field(default_factory=list)
    outputs: List[str] = field(default_factory=list)

    # --- Execution-related metadata ---
    policy: Dict[str, Any] = field(default_factory=dict)
    last_run_utc: Optional[str] = None
    last_run_meta: Optional[ExecMeta] = None


@dataclass(slots=True)
class Layer:
    """
    Represents a single depth layer in the quadtree.
    It contains a list of nodes, where each node is an integer representing
    its visual state (e.g., a color).
    """
    size: int
    nodes: List[int] = field(default_factory=list)


@dataclass(slots=True)
class Matrix:
    """
    Represents a complete quadtree context.
    It holds the geometric structure (layers of nodes) and a pool of payloads
    that contain the rich content for each cell.
    """
    quadtree_size: int
    max_depth: int
    layers: List[Layer] = field(default_factory=list)
    payload_pool: Dict[str, CellPayload] = field(default_factory=dict)
    version: int = 2
