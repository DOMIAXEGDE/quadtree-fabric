"""
main.py

This is the main entry point for the Quadtree Fabric application.

Its responsibilities include:
- Parsing command-line arguments.
- Setting up the necessary environment for multiprocessing.
- Initializing and running the main application class.
"""

import sys
from argparse import ArgumentParser
from multiprocessing import freeze_support

# We use a try/except block for the main application import to provide
# a cleaner error message if dependencies like pygame are not installed.
try:
    from .app import QuadtreeApp
    from .config import SCREEN_WIDTH_DEFAULT, SCREEN_HEIGHT_DEFAULT
except ImportError as e:
    print(f"Error: Failed to import necessary modules. Please ensure all dependencies are installed.")
    print(f"Missing module: {e.name}")
    sys.exit(1)


def main():
    """
    Parses arguments, initializes the application, and starts the main loop.
    """
    # --- Argument Parsing ---
    parser = ArgumentParser(
        description="Quadtree Fabric: A visual, polyglot programming lab."
    )
    parser.add_argument(
        "--width",
        type=int,
        default=SCREEN_WIDTH_DEFAULT,
        help="The initial width of the application window in pixels."
    )
    parser.add_argument(
        "--height",
        type=int,
        default=SCREEN_HEIGHT_DEFAULT,
        help="The initial height of the application window in pixels."
    )
    args = parser.parse_args()

    # --- Application Initialization ---
    try:
        app = QuadtreeApp(width=args.width, height=args.height)
        app.run()
    except Exception as e:
        # Catch any unhandled exceptions during app execution for graceful exit.
        print(f"An unexpected error occurred: {e}")
        # In a real application, you might log this to a file.
        # For now, printing to the console is sufficient.
        sys.exit(1)


if __name__ == "__main__":
    # The `freeze_support()` call is essential for creating frozen executables
    # (e.g., with PyInstaller or cx_Freeze) on platforms like Windows. It
    # ensures that child processes created for code execution can correctly
    # re-initialize the application's environment.
    freeze_support()
    main()
