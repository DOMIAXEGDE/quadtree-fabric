"""
core/matrix_handler.py

This module defines the MatrixHandler class, which serves as the primary
interface for all data manipulation and state management of the quadtree
matrices. It encapsulates the core business logic for creating, modifying,
and accessing quadtree contexts and their cell payloads.
"""

from __future__ import annotations
from typing import Dict, List, Optional, Tuple

from ..data_models import Layer, Matrix, CellPayload


class MatrixHandler:
    """
    Manages the state and operations for all quadtree contexts in the application.
    """

    def __init__(self):
        # A dictionary to hold all loaded quadtree contexts, keyed by a unique ID.
        self.contexts: Dict[str, Matrix] = {}
        self.current_context_id: Optional[str] = None

    def get_current_context(self) -> Optional[Matrix]:
        """
        Retrieves the currently active Matrix object.

        Returns:
            The active Matrix, or None if no context is currently selected.
        """
        if self.current_context_id:
            return self.contexts.get(self.current_context_id)
        return None

    def create_new_context(self, context_id: str, size: int, max_depth: int) -> Matrix:
        """
        Creates a new, empty Matrix and adds it to the handler.

        Args:
            context_id: The unique identifier for the new context.
            size: The pixel dimension of the quadtree canvas.
            max_depth: The maximum number of subdivisions allowed.

        Returns:
            The newly created Matrix object.
        """
        if context_id in self.contexts:
            raise ValueError(f"Context with ID '{context_id}' already exists.")

        layers = []
        for d in range(max_depth + 1):
            layer_size = 1 << d
            nodes = [0] * (layer_size * layer_size)
            layers.append(Layer(size=layer_size, nodes=nodes))

        matrix = Matrix(
            quadtree_size=size,
            max_depth=max_depth,
            layers=layers,
            payload_pool={}
        )
        self.contexts[context_id] = matrix
        self.current_context_id = context_id
        return matrix

    def set_cell_payload(self, cell_coords: Tuple[int, int], payload: CellPayload) -> bool:
        """
        Assigns a payload to a specific cell in the current context.

        Args:
            cell_coords: A tuple of (depth, index) specifying the cell.
            payload: The CellPayload object to assign.

        Returns:
            True if the payload was set successfully, False otherwise.
        """
        matrix = self.get_current_context()
        if not matrix:
            return False

        depth, index = cell_coords
        key = f"{depth}:{index}"
        matrix.payload_pool[key] = payload
        return True

    def get_cell_payload(self, cell_coords: Tuple[int, int]) -> Optional[CellPayload]:
        """
        Retrieves the payload from a specific cell in the current context.

        Args:
            cell_coords: A tuple of (depth, index) specifying the cell.

        Returns:
            The CellPayload object, or None if no payload exists for that cell.
        """
        matrix = self.get_current_context()
        if not matrix:
            return None

        depth, index = cell_coords
        key = f"{depth}:{index}"
        return matrix.payload_pool.get(key)

    def subdivide_cell(self, cell_coords: Tuple[int, int]) -> bool:
        """
        Subdivides a cell into four children, propagating its color and payload.

        Args:
            cell_coords: The (depth, index) of the parent cell to subdivide.

        Returns:
            True if subdivision was successful, False otherwise (e.g., at max depth).
        """
        matrix = self.get_current_context()
        if not matrix:
            return False

        parent_depth, parent_index = cell_coords
        if parent_depth >= matrix.max_depth:
            return False  # Cannot subdivide beyond the maximum depth.

        child_depth = parent_depth + 1
        parent_layer = matrix.layers[parent_depth]
        child_layer = matrix.layers[child_depth]

        # Get parent properties
        parent_color = parent_layer.nodes[parent_index]
        parent_payload = self.get_cell_payload(cell_coords)

        # Calculate the top-left coordinate of the new 2x2 child grid
        parent_x = parent_index % parent_layer.size
        parent_y = parent_index // parent_layer.size
        child_base_x = parent_x * 2
        child_base_y = parent_y * 2

        # Assign properties to the four children
        for dy in range(2):
            for dx in range(2):
                child_x = child_base_x + dx
                child_y = child_base_y + dy
                child_index = child_y * child_layer.size + child_x

                child_layer.nodes[child_index] = parent_color
                if parent_payload:
                    # Create a deep copy of the payload for each child
                    self.set_cell_payload((child_depth, child_index), parent_payload)

        return True

    def list_context_ids(self) -> List[str]:
        """Returns a list of all currently loaded context IDs."""
        return list(self.contexts.keys())
