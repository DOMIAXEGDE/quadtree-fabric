"""
core/io_handler.py

This module defines the IOHandler, which is responsible for all file system
interactions. It handles the serialization and deserialization of quadtree
contexts to and from JSON files, and manages non-blocking file dialogs for
a smooth user experience.
"""

from __future__ import annotations
import json
import tkinter as tk
from tkinter import filedialog, simpledialog, colorchooser
from dataclasses import asdict, is_dataclass
from pathlib import Path
from concurrent.futures import ThreadPoolExecutor, Future
from typing import Any, Dict, Optional

from ..data_models import Matrix, Layer, CellPayload, ExecMeta


class _DataClassJSONEncoder(json.JSONEncoder):
    """A custom JSON encoder that can handle dataclasses."""
    def default(self, o: Any) -> Any:
        if is_dataclass(o):
            return asdict(o)
        return super().default(o)


class IOHandler:
    """
    Manages all file input/output operations for the application.
    """

    def __init__(self):
        # A thread pool to run blocking Tkinter dialogs without freezing the UI.
        self.dialog_pool = ThreadPoolExecutor(max_workers=1)

    # --- JSON Serialization/Deserialization ---

    def save_matrix_to_json(self, matrix: Matrix, filepath: str | Path) -> bool:
        """
        Serializes a Matrix object to a JSON file.

        Args:
            matrix: The Matrix object to save.
            filepath: The path to the destination JSON file.

        Returns:
            True if saving was successful, False otherwise.
        """
        try:
            with open(filepath, 'w', encoding='utf-8') as f:
                json.dump(matrix, f, cls=_DataClassJSONEncoder, indent=2)
            return True
        except (IOError, TypeError) as e:
            print(f"[IOHandler] Error saving matrix to {filepath}: {e}")
            return False

    def load_matrix_from_json(self, filepath: str | Path) -> Optional[Matrix]:
        """
        Deserializes a JSON file into a Matrix object.

        Args:
            filepath: The path to the source JSON file.

        Returns:
            A new Matrix object, or None if loading fails.
        """
        try:
            with open(filepath, 'r', encoding='utf-8') as f:
                data = json.load(f)

            # Reconstruct the Matrix object from the dictionary
            layers = [Layer(**layer_data) for layer_data in data.get("layers", [])]
            
            payload_pool: Dict[str, CellPayload] = {}
            for key, payload_data in data.get("payload_pool", {}).items():
                # Reconstruct nested ExecMeta if it exists
                if 'last_run_meta' in payload_data and payload_data['last_run_meta']:
                    payload_data['last_run_meta'] = ExecMeta(**payload_data['last_run_meta'])
                payload_pool[key] = CellPayload(**payload_data)

            return Matrix(
                quadtree_size=data["quadtree_size"],
                max_depth=data["max_depth"],
                layers=layers,
                payload_pool=payload_pool,
                version=data.get("version", 1) # Handle legacy files
            )
        except (IOError, json.JSONDecodeError, KeyError, TypeError) as e:
            print(f"[IOHandler] Error loading matrix from {filepath}: {e}")
            return None

    # --- Non-blocking Tkinter Dialogs ---

    def ask_open_json_path(self) -> Future:
        """Asynchronously asks the user to select a JSON file to open."""
        return self.dialog_pool.submit(
            lambda: filedialog.askopenfilename(
                title="Import Matrix Context",
                filetypes=[("JSON files", "*.json"), ("All files", "*.*")]
            )
        )

    def ask_save_json_path(self) -> Future:
        """Asynchronously asks the user for a path to save a JSON file."""
        return self.dialog_pool.submit(
            lambda: filedialog.asksaveasfilename(
                title="Export Matrix Context",
                defaultextension=".json",
                filetypes=[("JSON files", "*.json")]
            )
        )

    def ask_save_png_path(self) -> Future:
        """Asynchronously asks the user for a path to save a PNG image."""
        return self.dialog_pool.submit(
            lambda: filedialog.asksaveasfilename(
                title="Export Canvas as PNG",
                defaultextension=".png",
                filetypes=[("PNG images", "*.png")]
            )
        )
        
    def ask_open_image_path(self) -> Future:
        """Asynchronously asks the user to select an image file."""
        return self.dialog_pool.submit(
            lambda: filedialog.askopenfilename(
                title="Select Image for Cell",
                filetypes=[("Image files", "*.png;*.jpg;*.jpeg;*.gif;*.bmp")]
            )
        )

    def ask_for_string(self, title: str, prompt: str) -> Future:
        """Asynchronously asks the user for a string input."""
        return self.dialog_pool.submit(
            lambda: simpledialog.askstring(title, prompt)
        )

    def ask_for_color(self) -> Future:
        """Asynchronously asks the user to choose a color."""
        return self.dialog_pool.submit(
            lambda: colorchooser.askcolor(title="Choose Cell Color")[0]
        )

# --- Singleton Instance ---
# A single, global instance of the IOHandler for the application to use.
IO_HANDLER = IOHandler()
