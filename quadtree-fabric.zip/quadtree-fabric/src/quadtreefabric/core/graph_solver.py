"""
core/graph_solver.py

This module provides the logic for solving the execution order of a dependency
graph of quadtree cells. It uses topological sorting to create a linear
execution plan and includes robust cycle detection.
"""

from __future__ import annotations
from collections import deque
from typing import Dict, List, Set, Tuple

from ..data_models import CellPayload


class GraphSolver:
    """
    A solver for determining the execution order of a cell dependency graph.
    """

    def solve(self, payload_pool: Dict[str, CellPayload]) -> Tuple[List[str], List[str]]:
        """
        Performs a topological sort on the cells in the payload pool.

        Args:
            payload_pool: A dictionary mapping cell keys (e.g., "d:i") to
                          their CellPayload objects.

        Returns:
            A tuple containing:
            - A list of cell keys in a valid execution order.
            - A list of error messages. If this list is not empty, the
              execution order should not be trusted.
        """
        code_cells = {k: v for k, v in payload_pool.items() if v.type == 'code'}
        
        adj: Dict[str, Set[str]] = {key: set() for key in code_cells}
        in_degree: Dict[str, int] = {key: 0 for key in code_cells}
        
        # Build adjacency list and in-degree map
        for key, payload in code_cells.items():
            for dep_key in payload.inputs:
                if dep_key in code_cells:
                    # An edge exists from dep_key to key
                    if key not in adj[dep_key]:
                        adj[dep_key].add(key)
                        in_degree[key] += 1
                # We can optionally add a warning here for dependencies that don't exist
        
        # Initialize the queue with all nodes having an in-degree of 0
        queue = deque([key for key, degree in in_degree.items() if degree == 0])
        
        sorted_order: List[str] = []
        
        while queue:
            u = queue.popleft()
            sorted_order.append(u)
            
            for v in sorted(list(adj[u])): # Sort for deterministic output
                in_degree[v] -= 1
                if in_degree[v] == 0:
                    queue.append(v)
                    
        # Check for cycles
        if len(sorted_order) == len(code_cells):
            return sorted_order, []  # Success
        else:
            # Cycle detected
            errors = ["Error: A circular dependency was detected in the execution graph."]
            # Find the nodes involved in the cycle for a better error message
            cycle_nodes = [key for key, degree in in_degree.items() if degree > 0]
            errors.append(f"Cells involved in cycle: {', '.join(cycle_nodes)}")
            return [], errors

# --- Singleton Instance ---
GRAPH_SOLVER = GraphSolver()
