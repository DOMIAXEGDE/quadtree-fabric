"""
app.py

This module contains the main QuadtreeApp class, which orchestrates the
entire application. It initializes all subsystems, manages the main event
loop, and coordinates interactions between the UI, the core data handlers,
and the execution engine.
"""

from __future__ import annotations
import pygame
import atexit
from typing import Any, Dict, List, Optional, Tuple

# --- Core Subsystems ---
from .core.matrix_handler import MatrixHandler
from .core.io_handler import IO_HANDLER
from .execution.engine import ENGINE

# --- UI Components ---
from .ui.canvas import Canvas
from .ui.components import Button, DropDown, Slider, TextInput
from .ui.modals import CodeEditorModal, OutputModal, ExplorerModal
from .ui.context_menu import ContextMenu

# --- Configuration ---
from .config import COLORS, FONTS, SIDEBAR_WIDTH


class QuadtreeApp:
    """
    The main application class. It orchestrates all components and manages
    the main application loop.
    """

    def __init__(self, width: int, height: int):
        """Initializes Pygame, subsystems, and the main application window."""
        pygame.init()
        pygame.font.init()
        atexit.register(pygame.quit)

        self.width, self.height = width, height
        self.screen = pygame.display.set_mode((self.width, self.height))
        pygame.display.set_caption("Quadtree Fabric Lab")

        self.clock = pygame.time.Clock()
        self.running = True

        # --- Initialize Core Subsystems ---
        self.matrix_handler = MatrixHandler()
        self.execution_engine = ENGINE # Use the singleton instance

        # --- State Management ---
        self.current_depth = 0
        self.dialog_future: Optional[Any] = None
        self._dialog_handler: Optional[Callable] = None

        # --- Initialize UI ---
        self._load_fonts()
        self._setup_ui()

    def _load_fonts(self) -> None:
        """Loads all fonts specified in the config file."""
        self.fonts: Dict[str, pygame.font.Font] = {}
        for name, spec in FONTS.items():
            self.fonts[name] = pygame.font.SysFont(
                spec["name"],
                spec["size"],
                bold=spec.get("bold", False)
            )

    def _setup_ui(self) -> None:
        """Initializes all UI components and modals."""
        main_width = self.width - SIDEBAR_WIDTH
        self.canvas = Canvas(main_width, self.height, self.fonts)
        
        # --- Modals ---
        self.code_editor = CodeEditorModal(int(self.width * 0.7), int(self.height * 0.8), self.fonts)
        self.output_modal = OutputModal(int(self.width * 0.6), int(self.height * 0.5), self.fonts)
        self.explorer_modal = ExplorerModal(int(self.width * 0.7), int(self.height * 0.7), self.fonts, self._run_batch_cells)

        # --- Sidebar Controls ---
        self.context_dropdown = DropDown(10, 40, SIDEBAR_WIDTH - 20, 30, self.fonts["base"])
        self.new_ctx_btn = Button(10, 80, 80, 30, "+ New", self.fonts["base"], self._action_new_context)
        # ... other sidebar buttons ...
        self.depth_slider = Slider(10, 220, SIDEBAR_WIDTH - 20, 30, 0, 4, self.fonts["base"], 0, "Depth")
        
        self.sidebar_elements = [self.context_dropdown, self.new_ctx_btn, self.depth_slider]
        
        # --- Context Menu ---
        self.context_menu: Optional[ContextMenu] = None

        # --- Initial State ---
        self.matrix_handler.create_new_context("default", 400, 4)
        self._update_ui_from_state()

    def run(self) -> None:
        """Starts and manages the main application loop."""
        while self.running:
            dt = self.clock.tick(60) / 1000.0
            
            self._handle_events()
            self._update(dt)
            self._draw()

    def _handle_events(self) -> None:
        """Processes the event queue and dispatches events to handlers."""
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                self.running = False
                return

            # --- Event Dispatching Order (Topmost first) ---
            if self.code_editor.handle_event(event): continue
            if self.output_modal.handle_event(event): continue
            if self.explorer_modal.handle_event(event): continue
            if self.context_menu and self.context_menu.handle_event(event):
                self.context_menu = None
                continue
            
            # --- Sidebar and Canvas Events ---
            for element in self.sidebar_elements:
                if element.handle_event(event):
                    self._on_ui_interaction(element, element.handle_event(event))
                    continue

            if event.type == pygame.MOUSEBUTTONDOWN:
                if event.button == 3: # Right-click for context menu
                    self._handle_right_click(event.pos)
                elif self.context_menu: # Left-click dismisses context menu
                    self.context_menu = None

    def _update(self, dt: float) -> None:
        """Updates the state of the application and UI components."""
        self.code_editor.update(dt)
        
        # Check for completed async dialogs
        if self.dialog_future and self.dialog_future.done():
            result = self.dialog_future.result()
            if self._dialog_handler:
                self._dialog_handler(result)
            self.dialog_future = None
            self._dialog_handler = None

    def _draw(self) -> None:
        """Renders the entire application screen."""
        self.screen.fill(COLORS["surface"])
        
        # --- Draw Main Canvas ---
        current_matrix = self.matrix_handler.get_current_context()
        if current_matrix:
            self.canvas.draw(current_matrix, self.current_depth)
        self.screen.blit(self.canvas.surface, (SIDEBAR_WIDTH, 0))

        # --- Draw Sidebar ---
        sidebar_rect = pygame.Rect(0, 0, SIDEBAR_WIDTH, self.height)
        pygame.draw.rect(self.screen, COLORS["surface"], sidebar_rect)
        for element in self.sidebar_elements:
            element.draw(self.screen)

        # --- Draw Modals and Context Menu (on top) ---
        self.code_editor.draw(self.screen)
        self.output_modal.draw(self.screen)
        self.explorer_modal.draw(self.screen)
        if self.context_menu:
            self.context_menu.draw(self.screen)

        pygame.display.flip()

    # --- UI Actions and Callbacks ---

    def _action_new_context(self):
        """Handles the 'New Context' button action."""
        self._dialog_handler = self._handle_new_context_result
        self.dialog_future = IO_HANDLER.ask_for_string("New Context", "Enter context ID:")

    def _handle_new_context_result(self, context_id: Optional[str]):
        """Callback for when the new context dialog completes."""
        if context_id:
            # TODO: Get size and depth from UI inputs
            self.matrix_handler.create_new_context(context_id, 400, 4)
            self._update_ui_from_state()

    def _run_batch_cells(self, cells_to_run: List[Tuple[str, int, int]]):
        """Callback for the explorer to run multiple cells."""
        # This would ideally use a more complex job queue system
        for ctx_id, d, idx in cells_to_run:
            # This is a simplified execution flow
            matrix = self.matrix_handler.contexts.get(ctx_id)
            if not matrix: continue
            payload = matrix.payload_pool.get(f"{d}:{idx}")
            if payload and payload.type == 'code':
                result = self.execution_engine.execute(
                    lang=payload.content.get('language', ''),
                    code=payload.content.get('code', '')
                )
                payload.last_run_meta = result
                # In a real app, we'd queue results for the output modal
                if not result.ok:
                    self.output_modal.show(result)
                    break # Stop on first error for simplicity

    def _handle_right_click(self, pos: Tuple[int, int]):
        """Handles a right-click on the canvas to open the context menu."""
        matrix = self.matrix_handler.get_current_context()
        if not matrix: return
        
        cell = self.canvas.get_cell_at_pos(pos, matrix, self.current_depth, SIDEBAR_WIDTH)
        if cell:
            # TODO: Build the options list dynamically based on cell content
            options = [
                ("Add Code", lambda: print(f"Add code to {cell}")),
                ("---", None),
                ("Subdivide", lambda: print(f"Subdivide {cell}"))
            ]
            self.context_menu = ContextMenu(pos[0], pos[1], 200, options, self.fonts)

    def _on_ui_interaction(self, element: Any, result: Any):
        """Handles the result of a UI element interaction."""
        if element == self.depth_slider:
            self.current_depth = result
        elif element == self.context_dropdown:
            self.matrix_handler.current_context_id = result
            self._update_ui_from_state()

    def _update_ui_from_state(self):
        """Updates the UI to reflect the current application state."""
        self.context_dropdown.options = self.matrix_handler.list_context_ids()
        self.context_dropdown.selected = self.matrix_handler.current_context_id or ""
        
        matrix = self.matrix_handler.get_current_context()
        if matrix:
            self.depth_slider.max_val = matrix.max_depth
            self.current_depth = min(self.current_depth, matrix.max_depth)
            self.depth_slider.value = self.current_depth
