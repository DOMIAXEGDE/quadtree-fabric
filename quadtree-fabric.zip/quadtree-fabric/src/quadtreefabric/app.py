"""
app.py

This module contains the main QuadtreeApp class, which orchestrates the
entire application. It initializes all subsystems, manages the main event
loop, and coordinates interactions between the UI, the core data handlers,
and the execution engine.
"""

from __future__ import annotations
import pygame
import atexit
import base64
import os
import platform
import subprocess
import time
from pathlib import Path
from typing import Any, Callable, Dict, List, Optional, Tuple

# --- Core Subsystems ---
from .core.matrix_handler import MatrixHandler
from .core.io_handler import IO_HANDLER
from .core.graph_solver import GRAPH_SOLVER
from .execution.engine import ENGINE
from .data_models import CellPayload

# --- UI Components ---
from .ui.canvas import Canvas
from .ui.components import Button, DropDown, Slider, TextInput
from .ui.modals import CodeEditorModal, OutputModal, ExplorerModal
from .ui.context_menu import ContextMenu

# --- Configuration ---
from .config import COLORS, FONTS, SIDEBAR_WIDTH


class QuadtreeApp:
    """
    The main application class. It orchestrates all components and manages
    the main application loop.
    """

    def __init__(self, width: int, height: int):
        """Initializes Pygame, subsystems, and the main application window."""
        pygame.init()
        pygame.font.init()
        atexit.register(pygame.quit)

        self.width, self.height = width, height
        self.screen = pygame.display.set_mode((self.width, self.height))
        pygame.display.set_caption("Quadtree Fabric Lab")

        self.clock = pygame.time.Clock()
        self.running = True

        self.matrix_handler = MatrixHandler()
        self.execution_engine = ENGINE

        self.current_depth = 0
        self.dialog_future: Optional[Any] = None
        self._dialog_handler: Optional[Callable] = None

        self._load_fonts()
        self._setup_ui()

    def _load_fonts(self) -> None:
        """Loads all fonts specified in the config file."""
        self.fonts: Dict[str, pygame.font.Font] = {}
        for name, spec in FONTS.items():
            self.fonts[name] = pygame.font.SysFont(
                spec["name"],
                spec["size"],
                bold=spec.get("bold", False)
            )

    def _setup_ui(self) -> None:
        """Initializes all UI components and modals."""
        main_width = self.width - SIDEBAR_WIDTH
        self.canvas = Canvas(main_width, self.height, self.fonts)
        
        self.code_editor = CodeEditorModal(int(self.width * 0.7), int(self.height * 0.8), self.fonts)
        self.output_modal = OutputModal(int(self.width * 0.6), int(self.height * 0.5), self.fonts)
        self.explorer_modal = ExplorerModal(int(self.width * 0.8), int(self.height * 0.7), self.fonts, self._handle_explorer_run_request)

        btn_w, btn_h, margin = 80, 30, 10
        self.context_dropdown = DropDown(10, 40, SIDEBAR_WIDTH - 20, 30, self.fonts["base"])
        self.new_ctx_btn = Button(10, 80, btn_w, btn_h, "+ New", self.fonts["base"], self._action_new_context)
        self.import_ctx_btn = Button(10 + btn_w + margin, 80, btn_w, btn_h, "Import", self.fonts["base"], self._action_import_context)
        self.export_ctx_btn = Button(10 + (btn_w + margin) * 2, 80, btn_w, btn_h, "Export", self.fonts["base"], self._action_export_context)
        
        self.size_input = TextInput(10, 150, SIDEBAR_WIDTH - 20, 30, self.fonts["base"], label="Quadtree Size (px):")
        self.depth_slider = Slider(10, 220, SIDEBAR_WIDTH - 20, 30, 0, 4, self.fonts["base"], 0, "Depth")
        
        self.export_png_btn = Button(10, 260, SIDEBAR_WIDTH - 20, 30, "Export PNG", self.fonts["base"], self._action_export_png)
        self.new_exec_btn = Button(10, 300, SIDEBAR_WIDTH - 20, 30, "➕ New Executor", self.fonts["base"], self._action_new_executor)
        self.explorer_btn = Button(10, 340, SIDEBAR_WIDTH - 20, 30, "Cell Explorer", self.fonts["base"], self._action_open_explorer)

        self.sidebar_elements = [
            self.context_dropdown, self.new_ctx_btn, self.import_ctx_btn, self.export_ctx_btn,
            self.size_input, self.depth_slider, self.export_png_btn, self.new_exec_btn, self.explorer_btn
        ]
        
        self.context_menu: Optional[ContextMenu] = None

        self.matrix_handler.create_new_context("default", 400, 4)
        self._update_ui_from_state()

    def run(self) -> None:
        """Starts and manages the main application loop."""
        while self.running:
            dt = self.clock.tick(60) / 1000.0
            
            self._handle_events()
            self._update(dt)
            self._draw()

    def _handle_events(self) -> None:
        """Processes the event queue and dispatches events to handlers."""
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                self.running = False
                return

            modal_result = self.code_editor.handle_event(event)
            if modal_result:
                self._handle_modal_result(modal_result)
                continue
            
            output_modal_result = self.output_modal.handle_event(event)
            if output_modal_result and isinstance(output_modal_result, dict):
                if output_modal_result.get('action') == 'open_artifact':
                    self._action_open_artifact(output_modal_result.get('path'))
                continue
            elif output_modal_result:
                continue

            if self.explorer_modal.handle_event(event): continue
            
            if self.context_menu:
                if self.context_menu.handle_event(event):
                    self.context_menu = None
                elif event.type == pygame.MOUSEBUTTONDOWN:
                    self.context_menu = None
                continue

            for element in self.sidebar_elements:
                result = element.handle_event(event)
                if result not in (False, None, True):
                    self._on_ui_interaction(element, result)
                    continue

            if event.type == pygame.MOUSEBUTTONDOWN:
                if event.button == 1: # Left-click
                    for rect, path in self.canvas.artifact_rects.items():
                        if rect.collidepoint(event.pos):
                            self._action_open_artifact(path)
                            continue
                elif event.button == 3: # Right-click
                    self._handle_right_click(event.pos)

    def _update(self, dt: float) -> None:
        """Updates the state of the application and UI components."""
        self.code_editor.update(dt)
        for el in self.sidebar_elements:
            if hasattr(el, 'update'):
                el.update(dt)
        
        if self.dialog_future and self.dialog_future.done():
            result = self.dialog_future.result()
            if self._dialog_handler:
                self._dialog_handler(result)
            self.dialog_future = None
            self._dialog_handler = None

    def _draw(self) -> None:
        """Renders the entire application screen."""
        self.screen.fill(COLORS["surface"])
        
        current_matrix = self.matrix_handler.get_current_context()
        if current_matrix:
            self.canvas.draw(current_matrix, self.current_depth, SIDEBAR_WIDTH)
        self.screen.blit(self.canvas.surface, (SIDEBAR_WIDTH, 0))

        sidebar_rect = pygame.Rect(0, 0, SIDEBAR_WIDTH, self.height)
        pygame.draw.rect(self.screen, COLORS["surface"], sidebar_rect)
        for element in self.sidebar_elements:
            element.draw(self.screen)

        self.code_editor.draw(self.screen)
        self.output_modal.draw(self.screen)
        self.explorer_modal.draw(self.screen)
        if self.context_menu:
            self.context_menu.draw(self.screen)

        pygame.display.flip()

    # --- UI Action Callbacks ---

    def _action_new_context(self):
        self._dialog_handler = self._handle_new_context_result
        self.dialog_future = IO_HANDLER.ask_for_string("New Context", "Enter context ID:")

    def _action_import_context(self):
        self._dialog_handler = self._handle_import_context_result
        self.dialog_future = IO_HANDLER.ask_open_json_path()

    def _action_export_context(self):
        matrix = self.matrix_handler.get_current_context()
        if not matrix: return
        self._dialog_handler = lambda path: IO_HANDLER.save_matrix_to_json(matrix, path) if path else None
        self.dialog_future = IO_HANDLER.ask_save_json_path()

    def _action_export_png(self):
        self._dialog_handler = lambda path: pygame.image.save(self.canvas.surface, path) if path else None
        self.dialog_future = IO_HANDLER.ask_save_png_path()

    def _action_new_executor(self):
        template = 'def register(registry):\n    # registry.register(...)\n'
        self.code_editor.show(template, "python", None, [], [], [])

    def _action_open_explorer(self):
        matrix = self.matrix_handler.get_current_context()
        if matrix:
            self.explorer_modal.show(matrix)

    def _action_add_code(self, cell_coords):
        self.code_editor.show("", "python", cell_coords, self.execution_engine.list_available_languages(), [], [])

    def _action_edit_code(self, cell_coords):
        payload = self.matrix_handler.get_cell_payload(cell_coords)
        if payload and payload.type == 'code':
            self.code_editor.show(
                payload.content.get('code', ''),
                payload.content.get('language', 'python'),
                cell_coords,
                self.execution_engine.list_available_languages(),
                payload.inputs,
                payload.outputs,
                payload.last_run_meta
            )

    def _action_execute_code(self, cell_coords):
        payload = self.matrix_handler.get_cell_payload(cell_coords)
        if payload and payload.type == 'code':
            result = self.execution_engine.execute(
                lang=payload.content.get('language', ''),
                code=payload.content.get('code', '')
            )
            payload.last_run_meta = result
            self.output_modal.show(result)

    def _action_subdivide(self, cell_coords):
        if self.matrix_handler.subdivide_cell(cell_coords):
            self.current_depth += 1
            self._update_ui_from_state()

    def _action_open_artifact(self, path_str: Optional[str]):
        if not path_str: return
        path = Path(path_str)
        if not path.exists(): return
        
        try:
            if platform.system() == "Windows":
                os.startfile(path)
            elif platform.system() == "Darwin":
                subprocess.run(["open", path])
            else:
                subprocess.run(["xdg-open", path])
        except Exception as e:
            print(f"[App] Failed to open artifact: {e}")

    # --- Result Handlers ---

    def _handle_new_context_result(self, context_id: Optional[str]):
        if context_id and context_id not in self.matrix_handler.contexts:
            size = int(self.size_input.text)
            depth = self.depth_slider.max_val
            self.matrix_handler.create_new_context(context_id, size, depth)
            self._update_ui_from_state()

    def _handle_import_context_result(self, filepath: Optional[str]):
        if not filepath: return
        matrix = IO_HANDLER.load_matrix_from_json(filepath)
        if matrix:
            ctx_id = Path(filepath).stem
            base_id = ctx_id
            i = 1
            while ctx_id in self.matrix_handler.contexts:
                ctx_id = f"{base_id}_{i}"
                i += 1
            
            self.matrix_handler.contexts[ctx_id] = matrix
            self.matrix_handler.current_context_id = ctx_id
            self._update_ui_from_state()

    def _handle_modal_result(self, result: Dict[str, Any]):
        action = result.get('action')
        if action == 'save':
            if result.get('is_plugin'):
                pass
            else:
                inputs = [s.strip() for s in result['inputs'].split(',') if s.strip()]
                outputs = [s.strip() for s in result['outputs'].split(',') if s.strip()]
                payload = CellPayload(
                    type='code',
                    content={'language': result['lang'], 'code': result['code']},
                    inputs=inputs,
                    outputs=outputs
                )
                self.matrix_handler.set_cell_payload(result['cell'], payload)
            self.code_editor.hide()
        elif action == 'execute':
            exec_result = self.execution_engine.execute(result['lang'], result['code'])
            self.output_modal.show(exec_result)

    def _handle_explorer_run_request(self, mode: str, selected_keys: List[str]):
        """Handles all execution requests coming from the Explorer modal."""
        matrix = self.matrix_handler.get_current_context()
        if not matrix: return

        keys_to_run: List[str] = []
        if mode == 'all':
            keys_to_run = [k for k, p in matrix.payload_pool.items() if p.type == 'code']
        elif mode == 'selected':
            keys_to_run = selected_keys
        elif mode == 'failed':
            keys_to_run = [
                k for k, p in matrix.payload_pool.items() 
                if p.type == 'code' and p.last_run_meta and not p.last_run_meta.ok
            ]
        elif mode == 'graph':
            sorted_keys, errors = GRAPH_SOLVER.solve(matrix.payload_pool)
            if errors:
                # TODO: Show these errors in the output modal
                print("\n".join(errors))
                return
            keys_to_run = sorted_keys
        
        self._execute_cell_sequence(keys_to_run)

    def _execute_cell_sequence(self, cell_keys: List[str]):
        """Executes a list of cells in order, stopping on the first error."""
        for key in cell_keys:
            payload = self.matrix_handler.get_cell_payload(tuple(map(int, key.split(':'))))
            if payload and payload.type == 'code':
                result = self.execution_engine.execute(
                    lang=payload.content.get('language', ''),
                    code=payload.content.get('code', '')
                )
                payload.last_run_meta = result
                if not result.ok:
                    self.output_modal.show(result)
                    break

    def _handle_right_click(self, pos: Tuple[int, int]):
        matrix = self.matrix_handler.get_current_context()
        if not matrix: return
        
        cell = self.canvas.get_cell_at_pos(pos, matrix, self.current_depth, SIDEBAR_WIDTH)
        if cell:
            payload = self.matrix_handler.get_cell_payload(cell)
            options = []
            
            if payload and payload.type == 'code':
                options.append(("✏️ Edit Code", lambda: self._action_edit_code(cell)))
                options.append(("▶️ Execute Code", lambda: self._action_execute_code(cell)))
                if payload.last_run_meta and payload.last_run_meta.artifacts:
                    options.append(("---", None))
                    for name, path in payload.last_run_meta.artifacts.items():
                        options.append((f"📂 Open: {name}", lambda p=path: self._action_open_artifact(p)))
            else:
                options.append(("📝 Add Code", lambda: self._action_add_code(cell)))

            options.append(("---", None))
            if self.current_depth < matrix.max_depth:
                options.append(("↪ Subdivide", lambda: self._action_subdivide(cell)))
            
            self.context_menu = ContextMenu(pos[0], pos[1], 200, options, self.fonts)

    def _on_ui_interaction(self, element: Any, result: Any):
        if element == self.depth_slider:
            self.current_depth = result
        elif element == self.context_dropdown:
            self.matrix_handler.current_context_id = result
            self._update_ui_from_state()
        elif element == self.size_input:
            try:
                size = int(result)
                if self.matrix_handler.get_current_context():
                    self.matrix_handler.get_current_context().quadtree_size = size
            except (ValueError, TypeError):
                pass

    def _update_ui_from_state(self):
        self.context_dropdown.options = self.matrix_handler.list_context_ids()
        self.context_dropdown.selected = self.matrix_handler.current_context_id or ""
        
        matrix = self.matrix_handler.get_current_context()
        if matrix:
            self.depth_slider.max_val = matrix.max_depth
            self.current_depth = min(self.current_depth, matrix.max_depth)
            self.depth_slider.value = self.current_depth
            self.size_input.text = str(matrix.quadtree_size)
