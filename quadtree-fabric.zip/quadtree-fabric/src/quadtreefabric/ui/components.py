"""
ui/components.py

This module provides a collection of basic, reusable UI widgets for the
Quadtree Fabric application. Each class is self-contained, managing its
own state, rendering, and event handling.
"""

from __future__ import annotations
import pygame
from typing import Any, Callable, List, Optional, Tuple

from ..config import COLORS


class Button:
    """
    A standard clickable button widget.
    """
    def __init__(
        self,
        x: int, y: int,
        width: int, height: int,
        text: str,
        font: pygame.font.Font,
        action: Optional[Callable[[], Any]] = None,
        disabled: bool = False
    ):
        self.rect = pygame.Rect(x, y, width, height)
        self.text = text
        self.font = font
        self.action = action
        self.disabled = disabled
        self.hovered = False
        self.pressed = False

    def draw(self, surface: pygame.Surface) -> None:
        """Renders the button to the given surface."""
        if self.disabled:
            color = COLORS["accent"]
        elif self.pressed:
            color = COLORS["secondary"]
        else:
            color = COLORS["button_hover"] if self.hovered else COLORS["primary"]

        pygame.draw.rect(surface, color, self.rect, border_radius=4)

        # FIX: Explicitly cast text to string to prevent TypeError.
        text_surf = self.font.render(str(self.text), True, COLORS["surface"])
        text_rect = text_surf.get_rect(center=self.rect.center)
        surface.blit(text_surf, text_rect)

    def check_hover(self, pos: Tuple[int, int]) -> bool:
        """Updates the hover state based on the mouse position."""
        self.hovered = self.rect.collidepoint(pos) and not self.disabled
        return self.hovered

    def handle_event(self, event: pygame.event.Event) -> Any:
        """
        Processes a single pygame event and triggers the button's action
        if clicked. Returns the result of the action, or False.
        """
        if self.disabled:
            return False

        if event.type == pygame.MOUSEBUTTONDOWN and event.button == 1:
            if self.rect.collidepoint(event.pos):
                self.pressed = True
                return False

        if event.type == pygame.MOUSEBUTTONUP and event.button == 1:
            if self.pressed and self.rect.collidepoint(event.pos):
                self.pressed = False
                if self.action:
                    return self.action()
                return True
            self.pressed = False

        return False


class DropDown:
    """
    A dropdown menu widget that allows selecting from a list of options.
    """
    def __init__(
        self,
        x: int, y: int,
        width: int, height: int,
        font: pygame.font.Font,
        options: Optional[List[str]] = None
    ):
        self.rect = pygame.Rect(x, y, width, height)
        self.font = font
        self.options = options or []
        self.selected = ""
        self.is_open = False
        self.hovered = False
        self.hovered_index = -1

    def draw(self, surface: pygame.Surface) -> None:
        """Renders the dropdown box and its options if open."""
        box_color = COLORS["button_hover"] if self.hovered else COLORS["surface"]
        pygame.draw.rect(surface, box_color, self.rect, border_radius=4)
        pygame.draw.rect(surface, COLORS["accent"], self.rect, width=1, border_radius=4)

        # FIX: Explicitly cast selected text to string.
        text_to_render = str(self.selected or "Select...")
        text_surf = self.font.render(text_to_render, True, COLORS["text"])
        surface.blit(text_surf, (self.rect.x + 10, self.rect.centery - text_surf.get_height() // 2))

        arrow_points = [
            (self.rect.right - 15, self.rect.centery - 3),
            (self.rect.right - 10, self.rect.centery + 3),
            (self.rect.right - 5, self.rect.centery - 3),
        ]
        pygame.draw.polygon(surface, COLORS["accent"], arrow_points)

        if self.is_open:
            self._draw_options(surface)

    def _draw_options(self, surface: pygame.Surface) -> None:
        """Renders the dropdown's option list."""
        option_height = 25
        dropdown_rect = pygame.Rect(self.rect.x, self.rect.bottom, self.rect.width, option_height * len(self.options))
        pygame.draw.rect(surface, COLORS["surface"], dropdown_rect)
        pygame.draw.rect(surface, COLORS["accent"], dropdown_rect, width=1)

        for i, option in enumerate(self.options):
            option_rect = pygame.Rect(self.rect.x, self.rect.bottom + i * option_height, self.rect.width, option_height)
            if i == self.hovered_index:
                pygame.draw.rect(surface, COLORS["bg"], option_rect)

            # FIX: Explicitly cast option text to string.
            text_surf = self.font.render(str(option), True, COLORS["text"])
            surface.blit(text_surf, (option_rect.x + 10, option_rect.centery - text_surf.get_height() // 2))

    def check_hover(self, pos: Tuple[int, int]) -> bool:
        """Updates the hover state for the main box and the options."""
        self.hovered = self.rect.collidepoint(pos)
        self.hovered_index = -1
        if self.is_open:
            option_height = 25
            for i in range(len(self.options)):
                option_rect = pygame.Rect(self.rect.x, self.rect.bottom + i * option_height, self.rect.width, option_height)
                if option_rect.collidepoint(pos):
                    self.hovered_index = i
                    return True
        return self.hovered

    def handle_event(self, event: pygame.event.Event) -> Any:
        """
        Processes events for opening, closing, and selecting options.
        Returns the selected option string, or False.
        """
        if event.type == pygame.MOUSEBUTTONDOWN and event.button == 1:
            if self.rect.collidepoint(event.pos):
                self.is_open = not self.is_open
                return True

            if self.is_open:
                if self.hovered_index != -1:
                    self.selected = self.options[self.hovered_index]
                    self.is_open = False
                    return self.selected
                else:
                    self.is_open = False
        return False


class Slider:
    """
    A horizontal slider widget for selecting a value within a range.
    """
    def __init__(
        self,
        x: int, y: int,
        width: int, height: int,
        min_val: int, max_val: int,
        font: pygame.font.Font,
        initial_val: int,
        label: Optional[str] = None
    ):
        self.rect = pygame.Rect(x, y, width, height)
        self.font = font
        self.min_val, self.max_val = min_val, max_val
        self.value = initial_val
        self.label = label
        self.handle_radius = 8
        self.dragging = False
        self.hovered = False

    def draw(self, surface: pygame.Surface) -> None:
        """Renders the slider track, handle, and label."""
        track_rect = pygame.Rect(self.rect.x, self.rect.centery - 2, self.rect.width, 4)
        pygame.draw.rect(surface, COLORS["accent"], track_rect, border_radius=2)

        handle_x = self.rect.x + int(((self.value - self.min_val) / (self.max_val - self.min_val)) * self.rect.width)
        radius = self.handle_radius + 2 if (self.hovered or self.dragging) else self.handle_radius
        color = COLORS["secondary"] if (self.hovered or self.dragging) else COLORS["primary"]
        pygame.draw.circle(surface, color, (handle_x, self.rect.centery), radius)

        if self.label:
            # FIX: Explicitly cast the formatted label text to a string.
            label_text = f"{self.label}: {self.value}"
            text_surf = self.font.render(str(label_text), True, COLORS["text"])
            surface.blit(text_surf, (self.rect.x, self.rect.y - text_surf.get_height() - 2))

    def _update_value_from_pos(self, x_pos: int) -> None:
        """Helper to update the slider's value based on a mouse x-coordinate."""
        relative_x = max(0, min(x_pos - self.rect.x, self.rect.width))
        raw_value = self.min_val + (relative_x / self.rect.width) * (self.max_val - self.min_val)
        self.value = int(round(raw_value))

    def check_hover(self, pos: Tuple[int, int]) -> bool:
        """Updates the hover state based on proximity to the handle."""
        handle_x = self.rect.x + int(((self.value - self.min_val) / (self.max_val - self.min_val)) * self.rect.width)
        handle_rect = pygame.Rect(handle_x - self.handle_radius, self.rect.centery - self.handle_radius, self.handle_radius * 2, self.handle_radius * 2)
        self.hovered = handle_rect.collidepoint(pos)
        return self.hovered

    def handle_event(self, event: pygame.event.Event) -> Any:
        """
        Processes events for dragging the slider handle.
        Returns the new value when it changes, or False.
        """
        if event.type == pygame.MOUSEBUTTONDOWN and event.button == 1:
            if self.rect.collidepoint(event.pos):
                self.dragging = True
                self._update_value_from_pos(event.pos[0])
                return self.value

        if event.type == pygame.MOUSEBUTTONUP and event.button == 1:
            self.dragging = False

        if event.type == pygame.MOUSEMOTION and self.dragging:
            self._update_value_from_pos(event.pos[0])
            return self.value

        return False


class TextInput:
    """
    A single-line text input box.
    """
    def __init__(
        self,
        x: int, y: int,
        width: int, height: int,
        font: pygame.font.Font,
        initial_text: str = "",
        label: Optional[str] = None
    ):
        self.rect = pygame.Rect(x, y, width, height)
        self.font = font
        self.text = initial_text
        self.label = label
        self.active = False
        self.cursor_visible = True
        self.cursor_timer = 0

    def draw(self, surface: pygame.Surface) -> None:
        """Renders the text input box, text, and cursor."""
        border_color = COLORS["primary"] if self.active else COLORS["accent"]
        pygame.draw.rect(surface, COLORS["surface"], self.rect, border_radius=4)
        pygame.draw.rect(surface, border_color, self.rect, width=1, border_radius=4)

        # FIX: Explicitly cast text to string.
        text_surf = self.font.render(str(self.text), True, COLORS["text"])
        surface.blit(text_surf, (self.rect.x + 10, self.rect.centery - text_surf.get_height() // 2))

        if self.active and self.cursor_visible:
            cursor_x = self.rect.x + 10 + text_surf.get_width()
            pygame.draw.line(surface, COLORS["text"], (cursor_x, self.rect.y + 5), (cursor_x, self.rect.bottom - 5))

        if self.label:
            # FIX: Explicitly cast label text to string.
            label_surf = self.font.render(str(self.label), True, COLORS["text"])
            surface.blit(label_surf, (self.rect.x, self.rect.y - label_surf.get_height() - 2))

    def update(self, dt: float) -> None:
        """Updates the cursor blink timer."""
        if self.active:
            self.cursor_timer += dt
            if self.cursor_timer >= 0.5:
                self.cursor_timer = 0
                self.cursor_visible = not self.cursor_visible

    def handle_event(self, event: pygame.event.Event) -> Any:
        """
        Processes events for activating the input and typing.
        Returns the final text when Enter is pressed, or False.
        """
        if event.type == pygame.MOUSEBUTTONDOWN and event.button == 1:
            self.active = self.rect.collidepoint(event.pos)
            return True

        if event.type == pygame.KEYDOWN and self.active:
            if event.key == pygame.K_RETURN:
                self.active = False
                return self.text
            elif event.key == pygame.K_BACKSPACE:
                self.text = self.text[:-1]
            else:
                self.text += event.unicode
            return True

        return False
