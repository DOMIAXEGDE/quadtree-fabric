"""
ui/modals.py

This module contains the definitions for all complex modal dialogs used in
the Quadtree Fabric application. Modals are used for focused, stateful
interactions like editing code, viewing output, and exploring cell data.
"""

from __future__ import annotations
import pygame
import tkinter as tk
import math
from typing import Any, Callable, Dict, List, Optional, Tuple

from .components import Button, DropDown
from ..config import COLORS, FONTS
from ..data_models import ExecMeta, Matrix


class BaseModal:
    """
    An abstract base class for all modal dialogs.
    It handles the common functionality of drawing an overlay and a background,
    and managing visibility.
    """
    def __init__(self, width: int, height: int, title: str, fonts: Dict[str, pygame.font.Font]):
        self.width, self.height = width, height
        self.title = title
        self.fonts = fonts
        self.visible = False
        self.rect = pygame.Rect(0, 0, width, height)
        self.elements: List[Any] = []

    def show(self, **kwargs) -> None:
        """Makes the modal visible and centers it on the screen."""
        screen_rect = pygame.display.get_surface().get_rect()
        self.rect.center = screen_rect.center
        self.visible = True

    def hide(self) -> None:
        """Hides the modal."""
        self.visible = False

    def draw(self, surface: pygame.Surface) -> None:
        """Draws the modal's background, overlay, and title."""
        if not self.visible:
            return

        overlay = pygame.Surface(surface.get_size(), pygame.SRCALPHA)
        overlay.fill((0, 0, 0, 128))
        surface.blit(overlay, (0, 0))

        pygame.draw.rect(surface, COLORS["surface"], self.rect, border_radius=4)
        pygame.draw.rect(surface, COLORS["accent"], self.rect, width=1, border_radius=4)

        title_rect = pygame.Rect(self.rect.x, self.rect.y, self.rect.width, 40)
        pygame.draw.rect(surface, COLORS["primary"], title_rect, border_top_left_radius=4, border_top_right_radius=4)
        title_surf = self.fonts["header"].render(self.title, True, COLORS["surface"])
        surface.blit(title_surf, title_surf.get_rect(center=title_rect.center))

    def handle_event(self, event: pygame.event.Event) -> Any:
        if not self.visible:
            return False

        if event.type == pygame.MOUSEBUTTONDOWN and event.button == 1:
            if not self.rect.collidepoint(event.pos):
                self.hide()
                return True
        
        return False


class CodeEditorModal(BaseModal):
    """
    A full-featured modal for editing code with support for multiple languages.
    """
    def __init__(self, width: int, height: int, fonts: Dict[str, pygame.font.Font]):
        super().__init__(width, height, "Code Editor", fonts)
        self.code: str = ""
        self.language: str = "python"
        self.cell_coords: Optional[Tuple[int, int]] = None
        self.is_plugin_editor: bool = False
        
        self.lines: List[str] = []
        self.cursor_pos: int = 0
        self.selection_start: int = 0
        self.selecting: bool = False
        self.scroll_x: int = 0
        self.scroll_y: int = 0
        
        self.cursor_timer: float = 0
        self.cursor_visible: bool = True
        
        self.inputs_text: str = ""
        self.outputs_text: str = ""
        self.active_input: Optional[str] = None
        
        # --- Diagnostics ---
        self.diagnostics: List[Dict[str, Any]] = []
        self.diagnostic_rects: Dict[pygame.Rect, str] = {}
        self.hovered_diagnostic: Optional[str] = None
        
        self._setup_ui()

    def _setup_ui(self):
        btn_w, btn_h, margin = 100, 30, 10
        
        self.save_button = Button(
            self.rect.right - btn_w - margin, self.rect.bottom - btn_h - margin,
            btn_w, btn_h, "Save", self.fonts["base"]
        )
        self.execute_button = Button(
            self.rect.right - btn_w * 2 - margin * 2, self.rect.bottom - btn_h - margin,
            btn_w, btn_h, "Execute", self.fonts["base"]
        )
        self.cancel_button = Button(
            self.rect.left + margin, self.rect.bottom - btn_h - margin,
            btn_w, btn_h, "Cancel", self.fonts["base"], action=self.hide
        )
        self.language_dropdown = DropDown(
            self.rect.left + btn_w + margin * 2, self.rect.bottom - btn_h - margin,
            150, btn_h, self.fonts["base"]
        )
        self.elements = [self.save_button, self.execute_button, self.cancel_button, self.language_dropdown]
        
        self.inputs_rect = pygame.Rect(self.rect.x + 10, self.rect.bottom - 115, self.rect.width - 20, 30)
        self.outputs_rect = pygame.Rect(self.rect.x + 10, self.rect.bottom - 75, self.rect.width - 20, 30)


    def show(self, code: str, language: str, cell_coords: Optional[Tuple[int, int]], available_langs: List[str], inputs: List[str], outputs: List[str], last_run_meta: Optional[ExecMeta] = None, is_plugin: bool = False):
        super().show()
        self.code = code
        self.lines = code.split('\n')
        self.language = language
        self.cell_coords = cell_coords
        self.is_plugin_editor = is_plugin
        self.inputs_text = ", ".join(inputs)
        self.outputs_text = ", ".join(outputs)
        self.diagnostics = last_run_meta.diagnostics if last_run_meta else []
        
        self.language_dropdown.options = available_langs
        self.language_dropdown.selected = language
        
        self.cursor_pos = len(code)
        self.selection_start = self.cursor_pos
        self.scroll_x = self.scroll_y = 0
        self._ensure_cursor_visible()

    def update(self, dt: float):
        self.cursor_timer += dt
        if self.cursor_timer > 0.5:
            self.cursor_timer = 0
            self.cursor_visible = not self.cursor_visible

    def draw(self, surface: pygame.Surface):
        if not self.visible:
            return
        super().draw(surface)
        
        editor_rect = pygame.Rect(self.rect.x + 10, self.rect.y + 45, self.rect.width - 20, self.rect.height - 160)
        
        for el in self.elements:
            el.draw(surface)
            
        self._draw_text_area(surface, editor_rect)
        self._draw_dataflow_inputs(surface)
        self._draw_tooltips(surface)

    def _draw_tooltips(self, surface: pygame.Surface):
        """Draws tooltips for hovered diagnostics."""
        if self.hovered_diagnostic:
            font = self.fonts["base"]
            lines = self.hovered_diagnostic.split('\n')
            surfaces = [font.render(line, True, COLORS["surface"]) for line in lines]
            width = max(s.get_width() for s in surfaces) + 10
            height = sum(s.get_height() for s in surfaces) + 10
            
            pos = pygame.mouse.get_pos()
            tooltip_rect = pygame.Rect(pos[0] + 15, pos[1], width, height)
            
            pygame.draw.rect(surface, COLORS["text"], tooltip_rect, border_radius=4)
            
            y_offset = 5
            for surf in surfaces:
                surface.blit(surf, (tooltip_rect.x + 5, tooltip_rect.y + y_offset))
                y_offset += surf.get_height()

    def _draw_text_area(self, surface: pygame.Surface, rect: pygame.Rect):
        self.diagnostic_rects.clear()
        font = self.fonts["mono"]
        line_height = font.get_height()
        char_width = font.size(' ')[0]
        gutter_width = 40
        
        text_area_rect = pygame.Rect(rect.left + gutter_width, rect.top, rect.width - gutter_width, rect.height)
        
        pygame.draw.rect(surface, COLORS["code"]["bg"], rect)
        gutter_rect = pygame.Rect(rect.left, rect.top, gutter_width, rect.height)
        pygame.draw.rect(surface, COLORS["accent"], gutter_rect)

        max_visible_lines = rect.height // line_height
        text_surface = surface.subsurface(text_area_rect)

        # Draw squiggles and diagnostics first, underneath text
        for diag in self.diagnostics:
            line_num = diag.get('line', -1) - 1 # 1-based to 0-based
            if self.scroll_y <= line_num < self.scroll_y + max_visible_lines:
                y = (line_num - self.scroll_y) * line_height
                
                # Gutter icon
                icon_rect = pygame.Rect(rect.left + 5, rect.top + y + 5, 10, 10)
                color = COLORS["code"]["error"] if diag.get('severity') == 'error' else (255, 193, 7)
                pygame.draw.circle(surface, color, icon_rect.center, 5)
                self.diagnostic_rects[icon_rect] = diag.get('message', 'No details.')
                
                # Squiggle
                col = diag.get('col', -1)
                if col != -1:
                    x_start = (col - 1 - self.scroll_x) * char_width
                    length = diag.get('length', len(self.lines[line_num]) - col + 1)
                    x_end = x_start + length * char_width
                    self._draw_squiggle(text_surface, color, (x_start, y + line_height - 2), (x_end, y + line_height - 2))

        # ... [rest of draw logic: selection, text, cursor] ...
        selection_start, selection_end = min(self.cursor_pos, self.selection_start), max(self.cursor_pos, self.selection_start)
        start_row, start_col = self._pos_to_row_col(selection_start)
        end_row, end_col = self._pos_to_row_col(selection_end)

        for i in range(start_row, end_row + 1):
            if self.scroll_y <= i < self.scroll_y + max_visible_lines:
                line_y = (i - self.scroll_y) * line_height
                
                sel_start_col = start_col if i == start_row else 0
                sel_end_col = end_col if i == end_row else len(self.lines[i])
                
                if sel_start_col < sel_end_col:
                    sel_x = (sel_start_col - self.scroll_x) * char_width
                    sel_width = (sel_end_col - sel_start_col) * char_width
                    sel_rect = pygame.Rect(sel_x, line_y, sel_width, line_height)
                    pygame.draw.rect(text_surface, COLORS["code"]["selection"], sel_rect)

        for i in range(max_visible_lines):
            line_idx = self.scroll_y + i
            if line_idx >= len(self.lines): break
            
            num_surf = font.render(str(line_idx + 1), True, COLORS["code"]["line_number"])
            surface.blit(num_surf, (rect.left + gutter_width - num_surf.get_width() - 5, rect.top + i * line_height))
            
            line_surf = font.render(self.lines[line_idx], True, COLORS["text"])
            text_surface.blit(line_surf, ((-self.scroll_x * char_width), i * line_height))

        if self.cursor_visible and not self.active_input:
            cursor_row, cursor_col = self._pos_to_row_col(self.cursor_pos)
            if self.scroll_y <= cursor_row < self.scroll_y + max_visible_lines:
                cursor_x = (cursor_col - self.scroll_x) * char_width
                cursor_y = (cursor_row - self.scroll_y) * line_height
                cursor_rect = pygame.Rect(cursor_x, cursor_y, 1, line_height)
                pygame.draw.rect(text_surface, COLORS["text"], cursor_rect)

    def _draw_squiggle(self, surface, color, start, end, amplitude=2, frequency=0.5):
        """Draws a wavy line."""
        points = []
        for x in range(int(start[0]), int(end[0])):
            y = start[1] + amplitude * math.sin(frequency * x)
            points.append((x, y))
        if len(points) > 1:
            pygame.draw.lines(surface, color, False, points, 1)

    def handle_event(self, event: pygame.event.Event) -> Any:
        if not self.visible: return False
        
        # Handle tooltip hover
        if event.type == pygame.MOUSEMOTION:
            self.hovered_diagnostic = None
            for rect, msg in self.diagnostic_rects.items():
                if rect.collidepoint(event.pos):
                    self.hovered_diagnostic = msg
                    break

        if super().handle_event(event): return True

        for el in self.elements:
            result = el.handle_event(event)
            if result:
                if el == self.save_button:
                    return {
                        'action': 'save', 'code': self.code, 'lang': self.language_dropdown.selected, 
                        'cell': self.cell_coords, 'is_plugin': self.is_plugin_editor,
                        'inputs': self.inputs_text, 'outputs': self.outputs_text
                    }
                if el == self.execute_button:
                    return {'action': 'execute', 'code': self.code, 'lang': self.language_dropdown.selected}
                return True

        if event.type == pygame.KEYDOWN:
            if self.active_input:
                self._handle_dataflow_input(event)
            else:
                self._handle_keyboard_input(event)
            return True
        elif event.type == pygame.MOUSEBUTTONDOWN:
            if self.inputs_rect.collidepoint(event.pos):
                self.active_input = 'inputs'
            elif self.outputs_rect.collidepoint(event.pos):
                self.active_input = 'outputs'
            else:
                self.active_input = None
                self._handle_mouse_click(event)
            return True
        elif event.type == pygame.MOUSEMOTION and self.selecting:
            self._handle_mouse_click(event)
            return True

        return False
    # ... [rest of CodeEditorModal methods are unchanged] ...
    def _draw_dataflow_inputs(self, surface: pygame.Surface):
        font = self.fonts["base"]
        
        pygame.draw.rect(surface, COLORS["surface"], self.inputs_rect, border_radius=4)
        border_color_in = COLORS["primary"] if self.active_input == 'inputs' else COLORS["accent"]
        pygame.draw.rect(surface, border_color_in, self.inputs_rect, 1, 4)
        in_label = font.render("Inputs (e.g., 0:1, 1:2):", True, COLORS["text"])
        surface.blit(in_label, (self.inputs_rect.x, self.inputs_rect.y - in_label.get_height() - 2))
        in_text = font.render(self.inputs_text, True, COLORS["text"])
        surface.blit(in_text, (self.inputs_rect.x + 5, self.inputs_rect.centery - in_text.get_height() // 2))

        pygame.draw.rect(surface, COLORS["surface"], self.outputs_rect, border_radius=4)
        border_color_out = COLORS["primary"] if self.active_input == 'outputs' else COLORS["accent"]
        pygame.draw.rect(surface, border_color_out, self.outputs_rect, 1, 4)
        out_label = font.render("Outputs (e.g., my_data):", True, COLORS["text"])
        surface.blit(out_label, (self.outputs_rect.x, self.outputs_rect.y - out_label.get_height() - 2))
        out_text = font.render(self.outputs_text, True, COLORS["text"])
        surface.blit(out_text, (self.outputs_rect.x + 5, self.outputs_rect.centery - out_text.get_height() // 2))

    def _handle_dataflow_input(self, event):
        target_text = self.inputs_text if self.active_input == 'inputs' else self.outputs_text
        
        if event.key == pygame.K_BACKSPACE:
            target_text = target_text[:-1]
        elif event.unicode:
            target_text += event.unicode
            
        if self.active_input == 'inputs':
            self.inputs_text = target_text
        else:
            self.outputs_text = target_text

    def _handle_keyboard_input(self, event):
        mods = pygame.key.get_mods()
        shift_pressed = mods & pygame.KMOD_SHIFT
        ctrl_pressed = mods & (pygame.KMOD_CTRL | pygame.KMOD_GUI)

        if not shift_pressed and event.key not in (pygame.K_LSHIFT, pygame.K_RSHIFT):
            self.selection_start = self.cursor_pos

        if ctrl_pressed and event.key == pygame.K_c:
            self._copy_selection()
        elif ctrl_pressed and event.key == pygame.K_x:
            self._copy_selection()
            self._delete_selection()
        elif ctrl_pressed and event.key == pygame.K_v:
            self._paste_from_clipboard()
        elif event.key == pygame.K_LEFT:
            self.cursor_pos = max(0, self.cursor_pos - 1)
        elif event.key == pygame.K_RIGHT:
            self.cursor_pos = min(len(self.code), self.cursor_pos + 1)
        elif event.key == pygame.K_UP:
            row, col = self._pos_to_row_col(self.cursor_pos)
            if row > 0:
                self.cursor_pos = self._row_col_to_pos(row - 1, col)
        elif event.key == pygame.K_DOWN:
            row, col = self._pos_to_row_col(self.cursor_pos)
            if row < len(self.lines) - 1:
                self.cursor_pos = self._row_col_to_pos(row + 1, col)
        elif event.key == pygame.K_HOME:
            row, _ = self._pos_to_row_col(self.cursor_pos)
            self.cursor_pos = self._row_col_to_pos(row, 0)
        elif event.key == pygame.K_END:
            row, _ = self._pos_to_row_col(self.cursor_pos)
            self.cursor_pos = self._row_col_to_pos(row, len(self.lines[row]))
        elif event.key == pygame.K_BACKSPACE:
            if self.cursor_pos == self.selection_start:
                if self.cursor_pos > 0:
                    self.code = self.code[:self.cursor_pos-1] + self.code[self.cursor_pos:]
                    self.cursor_pos -= 1
            else:
                self._delete_selection()
        elif event.key == pygame.K_DELETE:
            if self.cursor_pos == self.selection_start:
                if self.cursor_pos < len(self.code):
                    self.code = self.code[:self.cursor_pos] + self.code[self.cursor_pos+1:]
            else:
                self._delete_selection()
        elif event.key == pygame.K_RETURN:
            self._delete_selection()
            self.code = self.code[:self.cursor_pos] + '\n' + self.code[self.cursor_pos:]
            self.cursor_pos += 1
        elif event.key == pygame.K_TAB:
            self._delete_selection()
            self.code = self.code[:self.cursor_pos] + '    ' + self.code[self.cursor_pos:]
            self.cursor_pos += 4
        elif event.unicode:
            self._delete_selection()
            self.code = self.code[:self.cursor_pos] + event.unicode + self.code[self.cursor_pos:]
            self.cursor_pos += len(event.unicode)
        
        if not shift_pressed:
            self.selection_start = self.cursor_pos

        self.lines = self.code.split('\n')
        self._ensure_cursor_visible()

    def _handle_mouse_click(self, event):
        editor_rect = pygame.Rect(self.rect.x + 10, self.rect.y + 45, self.rect.width - 20, self.rect.height - 160)
        gutter_width = 40
        text_area_rect = pygame.Rect(editor_rect.left + gutter_width, editor_rect.top, editor_rect.width - gutter_width, editor_rect.height)
        
        if text_area_rect.collidepoint(event.pos):
            if event.type == pygame.MOUSEBUTTONDOWN:
                self.selecting = True

            font = self.fonts["mono"]
            line_height = font.get_height()
            char_width = font.size(' ')[0]
            
            row = self.scroll_y + (event.pos[1] - text_area_rect.top) // line_height
            col = self.scroll_x + round((event.pos[0] - text_area_rect.left) / char_width)
            
            self.cursor_pos = self._row_col_to_pos(row, col)
            if event.type == pygame.MOUSEBUTTONDOWN:
                 self.selection_start = self.cursor_pos
        
        if event.type == pygame.MOUSEBUTTONUP:
            self.selecting = False

    def _delete_selection(self):
        start, end = min(self.cursor_pos, self.selection_start), max(self.cursor_pos, self.selection_start)
        if start == end: return
        self.code = self.code[:start] + self.code[end:]
        self.cursor_pos = start
        self.selection_start = start

    def _copy_selection(self):
        start, end = min(self.cursor_pos, self.selection_start), max(self.cursor_pos, self.selection_start)
        if start != end:
            try:
                tk.Tk().clipboard_clear()
                tk.Tk().clipboard_append(self.code[start:end])
                tk.Tk().update()
            except tk.TclError:
                print("Warning: Could not access clipboard.")

    def _paste_from_clipboard(self):
        self._delete_selection()
        try:
            pasted_text = tk.Tk().clipboard_get()
            self.code = self.code[:self.cursor_pos] + pasted_text + self.code[self.cursor_pos:]
            self.cursor_pos += len(pasted_text)
            self.selection_start = self.cursor_pos
        except tk.TclError:
            pass

    def _pos_to_row_col(self, pos):
        pos = min(pos, len(self.code))
        row = self.code.count('\n', 0, pos)
        last_newline = self.code.rfind('\n', 0, pos)
        col = pos - (last_newline + 1)
        return row, col

    def _row_col_to_pos(self, row, col):
        row = min(row, len(self.lines) - 1)
        if row < 0: return 0
        col = min(col, len(self.lines[row]))
        pos = sum(len(line) + 1 for line in self.lines[:row]) + col
        return pos

    def _ensure_cursor_visible(self):
        editor_rect = pygame.Rect(self.rect.x + 10, self.rect.y + 45, self.rect.width - 20, self.rect.height - 160)
        gutter_width = 40
        text_area_rect = pygame.Rect(editor_rect.left + gutter_width, editor_rect.top, editor_rect.width - gutter_width, editor_rect.height)
        
        font = self.fonts["mono"]
        line_height = font.get_height()
        char_width = font.size(' ')[0]
        
        max_visible_lines = text_area_rect.height // line_height
        max_visible_cols = text_area_rect.width // char_width
        
        row, col = self._pos_to_row_col(self.cursor_pos)
        
        if row < self.scroll_y:
            self.scroll_y = row
        if row >= self.scroll_y + max_visible_lines:
            self.scroll_y = row - max_visible_lines + 1
            
        if col < self.scroll_x:
            self.scroll_x = col
        if col >= self.scroll_x + max_visible_cols:
            self.scroll_x = col - max_visible_cols + 1


class OutputModal(BaseModal):
    """
    A modal for displaying the output of a code execution.
    """
    def __init__(self, width: int, height: int, fonts: Dict[str, pygame.font.Font]):
        super().__init__(width, height, "Execution Output", fonts)
        self.exec_meta: Optional[ExecMeta] = None
        self.scroll_y = 0
        self.artifact_rects: Dict[pygame.Rect, str] = {}
        
        self._setup_ui()

    def _setup_ui(self):
        btn_w, btn_h, margin = 100, 30, 10
        self.close_button = Button(
            self.rect.right - btn_w - margin, self.rect.bottom - btn_h - margin,
            btn_w, btn_h, "Close", self.fonts["base"], action=self.hide
        )
        self.elements = [self.close_button]

    def show(self, exec_meta: ExecMeta):
        super().show()
        self.exec_meta = exec_meta
        self.scroll_y = 0
        self.title = "Execution Success" if exec_meta.ok else "Execution Failed"
        self.artifact_rects.clear()

    def draw(self, surface: pygame.Surface):
        if not self.visible or not self.exec_meta:
            return
        
        super().draw(surface)
        
        title_rect = pygame.Rect(self.rect.x, self.rect.y, self.rect.width, 40)
        color = COLORS["code"]["success"] if self.exec_meta.ok else COLORS["code"]["error"]
        pygame.draw.rect(surface, color, title_rect, border_top_left_radius=4, border_top_right_radius=4)
        title_surf = self.fonts["header"].render(self.title, True, COLORS["surface"])
        surface.blit(title_surf, title_surf.get_rect(center=title_rect.center))
        
        for el in self.elements:
            el.draw(surface)
            
        output_rect = pygame.Rect(self.rect.x + 10, self.rect.y + 45, self.rect.width - 20, self.rect.height - 100)
        pygame.draw.rect(surface, COLORS["code"]["bg"], output_rect)
        self._draw_output_content(surface.subsurface(output_rect))

    def _draw_output_content(self, surface: pygame.Surface):
        """Renders stdout, stderr, and artifacts."""
        self.artifact_rects.clear()
        font = self.fonts["mono"]
        line_height = font.get_height()
        
        content = [
            ("--- ARTIFACTS ---", COLORS["accent"]),
            *[(f"  - {name}", COLORS["primary"]) for name in self.exec_meta.artifacts.keys()],
            ("", COLORS["text"]),
            ("--- STDOUT ---", COLORS["accent"]),
            (self.exec_meta.stdout, COLORS["text"]),
            ("", COLORS["text"]),
            ("--- STDERR ---", COLORS["accent"]),
            (self.exec_meta.stderr, COLORS["code"]["error"]),
        ]
        
        y_pos = 5
        for text, color in content:
            lines = text.split('\n')
            for i, line in enumerate(lines):
                if y_pos < -self.scroll_y:
                    y_pos += line_height
                    continue
                if y_pos + self.scroll_y > surface.get_height():
                    break

                line_surf = font.render(line, True, color)
                draw_pos = (5, y_pos + self.scroll_y)
                surface.blit(line_surf, draw_pos)

                if text.startswith("  - ") and i == 0:
                    artifact_name = line.strip().split('- ')[1]
                    artifact_path = self.exec_meta.artifacts.get(artifact_name)
                    if artifact_path:
                        artifact_rect = line_surf.get_rect(topleft=(draw_pos[0] + surface.get_abs_offset()[0], draw_pos[1] + surface.get_abs_offset()[1]))
                        self.artifact_rects[artifact_rect] = artifact_path

                y_pos += line_height

    def handle_event(self, event: pygame.event.Event) -> Any:
        if not self.visible:
            return False
        if super().handle_event(event):
            return True
        
        for el in self.elements:
            if el.handle_event(event):
                return True
        
        if event.type == pygame.MOUSEBUTTONDOWN and event.button == 1:
            for rect, path in self.artifact_rects.items():
                if rect.collidepoint(event.pos):
                    return {'action': 'open_artifact', 'path': path}
                
        if event.type == pygame.MOUSEWHEEL:
            self.scroll_y -= event.y * 10
            self.scroll_y = min(0, self.scroll_y)
            return True
            
        return False


class ExplorerModal(BaseModal):
    """
    A modal for exploring, managing, and batch-executing all code cells
    in the current context.
    """
    ROW_HEIGHT = 25
    
    def __init__(self, width: int, height: int, fonts: Dict[str, pygame.font.Font], run_callback: Callable):
        super().__init__(width, height, "Cell Explorer", fonts)
        self.run_callback = run_callback
        self.matrix: Optional[Matrix] = None
        self.rows: List[Dict[str, Any]] = []
        self.selected_indices: set[int] = set()
        self.scroll_y = 0
        self.last_clicked_index = -1
        
        self._setup_ui()

    def _setup_ui(self):
        btn_w, btn_h, margin = 120, 30, 10
        bottom_y = self.rect.bottom - btn_h - margin
        
        self.run_all_btn = Button(self.rect.x + margin, bottom_y, btn_w, btn_h, "Run All", self.fonts["base"], lambda: self._run_handler('all'))
        self.run_sel_btn = Button(self.rect.x + margin * 2 + btn_w, bottom_y, btn_w, btn_h, "Run Selected", self.fonts["base"], lambda: self._run_handler('selected'))
        self.run_fail_btn = Button(self.rect.x + margin * 3 + btn_w * 2, bottom_y, btn_w, btn_h, "Run Failed", self.fonts["base"], lambda: self._run_handler('failed'))
        self.run_graph_btn = Button(self.rect.x + margin * 4 + btn_w * 3, bottom_y, btn_w, btn_h, "Run Graph", self.fonts["base"], lambda: self._run_handler('graph'))
        
        self.elements = [self.run_all_btn, self.run_sel_btn, self.run_fail_btn, self.run_graph_btn]

    def show(self, matrix: Matrix):
        super().show()
        self.matrix = matrix
        self.build_rows()
        self.selected_indices.clear()
        self.scroll_y = 0

    def build_rows(self):
        self.rows = []
        if not self.matrix: return
        
        for key, payload in self.matrix.payload_pool.items():
            if payload.type == 'code':
                d, idx = map(int, key.split(':'))
                self.rows.append({
                    'key': key,
                    'depth': d,
                    'index': idx,
                    'lang': payload.content.get('language', 'N/A'),
                    'lines': len(payload.content.get('code', '').split('\n')),
                    'last_run_meta': payload.last_run_meta
                })
        self.rows.sort(key=lambda r: (r['depth'], r['index']))

    def draw(self, surface: pygame.Surface):
        if not self.visible:
            return
        super().draw(surface)
        
        list_rect = pygame.Rect(self.rect.x + 10, self.rect.y + 45, self.rect.width - 20, self.rect.height - 100)
        pygame.draw.rect(surface, COLORS["code"]["bg"], list_rect)
        
        self._draw_rows(surface.subsurface(list_rect))
        
        for el in self.elements:
            el.draw(surface)

    def _draw_rows(self, surface: pygame.Surface):
        font = self.fonts["mono"]
        max_visible_lines = surface.get_height() // self.ROW_HEIGHT
        
        for i in range(max_visible_lines):
            row_idx = self.scroll_y + i
            if row_idx >= len(self.rows): break
            
            row_data = self.rows[row_idx]
            row_rect = pygame.Rect(0, i * self.ROW_HEIGHT, surface.get_width(), self.ROW_HEIGHT)
            
            if row_idx in self.selected_indices:
                pygame.draw.rect(surface, COLORS["code"]["selection"], row_rect)
            
            key = row_data['key']
            lang = row_data['lang']
            lines = row_data['lines']
            meta = row_data['last_run_meta']
            status = ""
            if meta:
                status = f"[{'OK' if meta.ok else 'ERR'}] {meta.wall_ms:.0f}ms"
            
            row_text = f"{key:<8} {lang:<10} {lines:>4}L  {status}"
            text_surf = font.render(row_text, True, COLORS["text"])
            surface.blit(text_surf, (5, row_rect.y + (self.ROW_HEIGHT - font.get_height()) // 2))

    def handle_event(self, event: pygame.event.Event) -> Any:
        if not self.visible:
            return False
        if super().handle_event(event):
            return True
            
        for el in self.elements:
            if el.handle_event(event):
                return True
        
        list_rect = pygame.Rect(self.rect.x + 10, self.rect.y + 45, self.rect.width - 20, self.rect.height - 100)
        if event.type == pygame.MOUSEBUTTONDOWN and event.button == 1:
            if list_rect.collidepoint(event.pos):
                clicked_row_index = self.scroll_y + (event.pos[1] - list_rect.top) // self.ROW_HEIGHT
                if 0 <= clicked_row_index < len(self.rows):
                    self._handle_row_selection(clicked_row_index)
                return True
                
        if event.type == pygame.MOUSEWHEEL:
            self.scroll_y -= event.y
            self.scroll_y = max(0, min(self.scroll_y, len(self.rows) - (list_rect.height // self.ROW_HEIGHT)))
            return True
            
        return False

    def _handle_row_selection(self, index: int):
        mods = pygame.key.get_mods()
        ctrl_pressed = mods & (pygame.KMOD_CTRL | pygame.KMOD_GUI)
        shift_pressed = mods & pygame.KMOD_SHIFT

        if ctrl_pressed:
            if index in self.selected_indices:
                self.selected_indices.remove(index)
            else:
                self.selected_indices.add(index)
        elif shift_pressed and self.last_clicked_index != -1:
            start = min(self.last_clicked_index, index)
            end = max(self.last_clicked_index, index)
            for i in range(start, end + 1):
                self.selected_indices.add(i)
        else:
            self.selected_indices.clear()
            self.selected_indices.add(index)
        
        self.last_clicked_index = index

    def _run_handler(self, mode: str):
        """A unified handler for all run buttons."""
        selected_keys = [self.rows[i]['key'] for i in self.selected_indices]
        self.run_callback(mode=mode, selected_keys=selected_keys)
        self.build_rows()
