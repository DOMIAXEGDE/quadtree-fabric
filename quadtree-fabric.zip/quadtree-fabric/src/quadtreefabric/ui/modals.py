"""
ui/modals.py

This module contains the definitions for all complex modal dialogs used in
the Quadtree Fabric application. Modals are used for focused, stateful
interactions like editing code, viewing output, and exploring cell data.
"""

from __future__ import annotations
import pygame
import tkinter as tk
from typing import Any, Callable, Dict, List, Optional, Tuple

from .components import Button, DropDown
from ..config import COLORS, FONTS
from ..data_models import ExecMeta, Matrix


class BaseModal:
    """
    An abstract base class for all modal dialogs.
    It handles the common functionality of drawing an overlay and a background,
    and managing visibility.
    """
    def __init__(self, width: int, height: int, title: str, fonts: Dict[str, pygame.font.Font]):
        self.width, self.height = width, height
        self.title = title
        self.fonts = fonts
        self.visible = False
        self.rect = pygame.Rect(0, 0, width, height)
        self.elements: List[Any] = []

    def show(self, **kwargs) -> None:
        """Makes the modal visible and centers it on the screen."""
        screen_rect = pygame.display.get_surface().get_rect()
        self.rect.center = screen_rect.center
        self.visible = True

    def hide(self) -> None:
        """Hides the modal."""
        self.visible = False

    def draw(self, surface: pygame.Surface) -> None:
        """Draws the modal's background, overlay, and title."""
        if not self.visible:
            return

        # Draw semi-transparent overlay
        overlay = pygame.Surface(surface.get_size(), pygame.SRCALPHA)
        overlay.fill((0, 0, 0, 128))
        surface.blit(overlay, (0, 0))

        # Draw modal background
        pygame.draw.rect(surface, COLORS["surface"], self.rect, border_radius=4)
        pygame.draw.rect(surface, COLORS["accent"], self.rect, width=1, border_radius=4)

        # Draw title bar
        title_rect = pygame.Rect(self.rect.x, self.rect.y, self.rect.width, 40)
        pygame.draw.rect(surface, COLORS["primary"], title_rect, border_top_left_radius=4, border_top_right_radius=4)
        title_surf = self.fonts["header"].render(self.title, True, COLORS["surface"])
        surface.blit(title_surf, title_surf.get_rect(center=title_rect.center))

    def handle_event(self, event: pygame.event.Event) -> Any:
        """
        Base event handler. Hides the modal if the user clicks outside of it.
        Child classes should extend this to handle their own elements.
        """
        if not self.visible:
            return False

        if event.type == pygame.MOUSEBUTTONDOWN and event.button == 1:
            if not self.rect.collidepoint(event.pos):
                self.hide()
                return True # Event consumed
        
        return False


class CodeEditorModal(BaseModal):
    """
    A full-featured modal for editing code with support for multiple languages.
    """
    def __init__(self, width: int, height: int, fonts: Dict[str, pygame.font.Font]):
        super().__init__(width, height, "Code Editor", fonts)
        self.code: str = ""
        self.language: str = "python"
        self.cell_coords: Optional[Tuple[int, int]] = None
        self.is_plugin_editor: bool = False
        
        # Text editing state
        self.cursor_pos: int = 0
        self.selection_start: int = 0
        self.selecting: bool = False
        self.scroll_x: int = 0
        self.scroll_y: int = 0
        
        # Cursor blinking
        self.cursor_timer: float = 0
        self.cursor_visible: bool = True
        
        self._setup_ui()

    def _setup_ui(self):
        """Creates the buttons and dropdown for the editor."""
        btn_w, btn_h, margin = 100, 30, 10
        
        self.save_button = Button(
            self.rect.right - btn_w - margin, self.rect.bottom - btn_h - margin,
            btn_w, btn_h, "Save", self.fonts["base"]
        )
        self.execute_button = Button(
            self.rect.right - btn_w * 2 - margin * 2, self.rect.bottom - btn_h - margin,
            btn_w, btn_h, "Execute", self.fonts["base"]
        )
        self.cancel_button = Button(
            self.rect.left + margin, self.rect.bottom - btn_h - margin,
            btn_w, btn_h, "Cancel", self.fonts["base"], action=self.hide
        )
        self.language_dropdown = DropDown(
            self.rect.left + btn_w + margin * 2, self.rect.bottom - btn_h - margin,
            150, btn_h, self.fonts["base"]
        )
        self.elements = [self.save_button, self.execute_button, self.cancel_button, self.language_dropdown]

    def show(self, code: str, language: str, cell_coords: Optional[Tuple[int, int]], available_langs: List[str], is_plugin: bool = False):
        """Shows the editor with specific code and context."""
        super().show()
        self.code = code
        self.language = language
        self.cell_coords = cell_coords
        self.is_plugin_editor = is_plugin
        
        self.language_dropdown.options = available_langs
        self.language_dropdown.selected = language
        
        # Reset state
        self.cursor_pos = len(code)
        self.selection_start = self.cursor_pos
        self.scroll_x = self.scroll_y = 0

    def update(self, dt: float):
        """Updates the cursor blink state."""
        self.cursor_timer += dt
        if self.cursor_timer > 0.5:
            self.cursor_timer = 0
            self.cursor_visible = not self.cursor_visible

    def draw(self, surface: pygame.Surface):
        """Draws the entire code editor modal."""
        if not self.visible:
            return
        super().draw(surface)
        
        # Draw editor area
        editor_rect = pygame.Rect(self.rect.x + 10, self.rect.y + 45, self.rect.width - 20, self.rect.height - 100)
        pygame.draw.rect(surface, COLORS["code"]["bg"], editor_rect)
        
        # Draw UI elements
        for el in self.elements:
            el.draw(surface)
            
        # Draw text and cursor
        self._draw_text_area(surface.subsurface(editor_rect))

    def _draw_text_area(self, surface: pygame.Surface):
        """Renders the code, line numbers, selection, and cursor."""
        font = self.fonts["mono"]
        line_height = font.get_height()
        char_width = font.size(' ')[0]
        
        lines = self.code.split('\n')
        max_visible_lines = surface.get_height() // line_height
        
        # Line numbers
        gutter_width = 40
        gutter_rect = pygame.Rect(0, 0, gutter_width, surface.get_height())
        pygame.draw.rect(surface, COLORS["accent"], gutter_rect)
        for i in range(max_visible_lines):
            line_num = self.scroll_y + i + 1
            if line_num > len(lines): break
            num_surf = font.render(str(line_num), True, COLORS["code"]["line_number"])
            surface.blit(num_surf, (gutter_width - num_surf.get_width() - 5, i * line_height))

        # Text Area
        text_area = surface.subsurface(pygame.Rect(gutter_width, 0, surface.get_width() - gutter_width, surface.get_height()))
        
        # TODO: Implement text selection drawing and cursor drawing
        # This is a complex task involving calculating character positions.
        
        for i, line in enumerate(lines[self.scroll_y : self.scroll_y + max_visible_lines]):
            line_surf = font.render(line, True, COLORS["text"])
            text_area.blit(line_surf, (-self.scroll_x * char_width, i * line_height))

    def handle_event(self, event: pygame.event.Event) -> Any:
        """Handles events for the code editor."""
        if not self.visible:
            return False
        
        # Let the base class handle clicks outside the modal first
        if super().handle_event(event):
            return True

        for el in self.elements:
            result = el.handle_event(event)
            if result:
                if el == self.save_button:
                    return {'action': 'save', 'code': self.code, 'lang': self.language_dropdown.selected, 'cell': self.cell_coords, 'is_plugin': self.is_plugin_editor}
                if el == self.execute_button:
                    return {'action': 'execute', 'code': self.code, 'lang': self.language_dropdown.selected}
                # Other elements handle their own state
                return True

        # TODO: Handle keyboard input for text editing (K_BACKSPACE, K_RETURN, unicode, etc.)
        # This is a significant implementation task.

        return False


class OutputModal(BaseModal):
    """
    A modal for displaying the output of a code execution.
    """
    def __init__(self, width: int, height: int, fonts: Dict[str, pygame.font.Font]):
        super().__init__(width, height, "Execution Output", fonts)
        self.exec_meta: Optional[ExecMeta] = None
        self.scroll_y = 0
        
        self._setup_ui()

    def _setup_ui(self):
        btn_w, btn_h, margin = 100, 30, 10
        self.close_button = Button(
            self.rect.right - btn_w - margin, self.rect.bottom - btn_h - margin,
            btn_w, btn_h, "Close", self.fonts["base"], action=self.hide
        )
        self.elements = [self.close_button]

    def show(self, exec_meta: ExecMeta):
        super().show()
        self.exec_meta = exec_meta
        self.scroll_y = 0
        self.title = "Execution Success" if exec_meta.ok else "Execution Failed"

    def draw(self, surface: pygame.Surface):
        if not self.visible or not self.exec_meta:
            return
        
        super().draw(surface)
        
        # Change title bar color based on success/failure
        title_rect = pygame.Rect(self.rect.x, self.rect.y, self.rect.width, 40)
        color = COLORS["code"]["success"] if self.exec_meta.ok else COLORS["code"]["error"]
        pygame.draw.rect(surface, color, title_rect, border_top_left_radius=4, border_top_right_radius=4)
        title_surf = self.fonts["header"].render(self.title, True, COLORS["surface"])
        surface.blit(title_surf, title_surf.get_rect(center=title_rect.center))
        
        for el in self.elements:
            el.draw(surface)
            
        # Draw output text
        output_rect = pygame.Rect(self.rect.x + 10, self.rect.y + 45, self.rect.width - 20, self.rect.height - 100)
        pygame.draw.rect(surface, COLORS["code"]["bg"], output_rect)
        self._draw_output_text(surface.subsurface(output_rect))

    def _draw_output_text(self, surface: pygame.Surface):
        """Renders the stdout and stderr from the ExecMeta object."""
        font = self.fonts["mono"]
        line_height = font.get_height()
        
        full_output = f"--- STDOUT ---\n{self.exec_meta.stdout}\n\n--- STDERR ---\n{self.exec_meta.stderr}"
        lines = full_output.split('\n')
        
        for i, line in enumerate(lines[self.scroll_y:]):
            y_pos = i * line_height
            if y_pos > surface.get_height():
                break
            line_surf = font.render(line, True, COLORS["text"])
            surface.blit(line_surf, (5, y_pos))

    def handle_event(self, event: pygame.event.Event) -> Any:
        if not self.visible:
            return False
        if super().handle_event(event):
            return True
        
        for el in self.elements:
            if el.handle_event(event):
                return True
                
        if event.type == pygame.MOUSEWHEEL:
            self.scroll_y = max(0, self.scroll_y - event.y)
            return True
            
        return False


class ExplorerModal(BaseModal):
    """
    A modal for exploring, managing, and batch-executing all code cells
    in the current context.
    """
    def __init__(self, width: int, height: int, fonts: Dict[str, pygame.font.Font], run_callback: Callable):
        super().__init__(width, height, "Cell Explorer", fonts)
        self.run_callback = run_callback
        self.matrix: Optional[Matrix] = None
        self.rows: List[Dict[str, Any]] = []
        self.selected_keys: set[str] = set()
        self.scroll_y = 0
        
        self._setup_ui()

    def _setup_ui(self):
        # TODO: Add buttons for "Run All", "Run Selected", "Run Failed"
        pass

    def show(self, matrix: Matrix):
        super().show()
        self.matrix = matrix
        self.build_rows()

    def build_rows(self):
        """Constructs the list of rows from the matrix's payload pool."""
        self.rows = []
        if not self.matrix: return
        
        for key, payload in self.matrix.payload_pool.items():
            if payload.type == 'code':
                d, idx = map(int, key.split(':'))
                self.rows.append({
                    'key': key,
                    'depth': d,
                    'index': idx,
                    'lang': payload.content.get('language', 'N/A'),
                    'lines': len(payload.content.get('code', '').split('\n')),
                    'last_run_meta': payload.last_run_meta
                })
        self.rows.sort(key=lambda r: (r['depth'], r['index']))

    def draw(self, surface: pygame.Surface):
        if not self.visible:
            return
        super().draw(surface)
        
        # TODO: Draw the rows of cell data
        # This will involve iterating through self.rows and rendering text.

    def handle_event(self, event: pygame.event.Event) -> Any:
        if not self.visible:
            return False
        if super().handle_event(event):
            return True
            
        # TODO: Handle row selection and button clicks
        
        if event.type == pygame.MOUSEWHEEL:
            self.scroll_y = max(0, self.scroll_y - event.y)
            return True
            
        return False
