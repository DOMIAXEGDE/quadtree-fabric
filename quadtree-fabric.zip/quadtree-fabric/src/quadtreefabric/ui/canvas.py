"""
ui/canvas.py

This module defines the Canvas class, which is responsible for all rendering
of the quadtree grid and its cell payloads. It encapsulates the drawing logic
for different payload types, such as text, code, and images, as well as
previews for generated artifacts.
"""

from __future__ import annotations
import base64
import io
import pygame
from PIL import Image
from typing import Any, Dict, Optional, Tuple

from ..config import COLORS
from ..data_models import Matrix, CellPayload, ExecMeta


class Canvas:
    """
    Manages the rendering of the quadtree canvas.
    """

    def __init__(self, width: int, height: int, fonts: Dict[str, pygame.font.Font]):
        self.surface = pygame.Surface((width, height))
        self.width = width
        self.height = height
        self.fonts = fonts
        
        # --- Artifact Visualization State ---
        self.thumbnail_cache: Dict[str, pygame.Surface] = {}
        self.artifact_rects: Dict[pygame.Rect, str] = {}

    def get_cell_at_pos(
        self,
        pos: Tuple[int, int],
        matrix: Matrix,
        current_depth: int,
        sidebar_width: int
    ) -> Optional[Tuple[int, int]]:
        """
        Calculates which cell, if any, is at a given screen position.
        """
        layer = matrix.layers[current_depth]
        cell_size = matrix.quadtree_size / layer.size
        
        offset_x = (self.width - matrix.quadtree_size) // 2 + sidebar_width
        offset_y = (self.height - matrix.quadtree_size) // 2

        rel_x = pos[0] - offset_x
        rel_y = pos[1] - offset_y

        if 0 <= rel_x < matrix.quadtree_size and 0 <= rel_y < matrix.quadtree_size:
            col = int(rel_x // cell_size)
            row = int(rel_y // cell_size)
            index = row * layer.size + col
            return (current_depth, index)
        
        return None

    def draw(self, matrix: Matrix, current_depth: int, sidebar_width: int) -> None:
        """
        Renders the entire quadtree grid for the given context and depth.
        """
        self.surface.fill(COLORS["bg"])
        self.artifact_rects.clear()
        
        if not matrix:
            return

        layer = matrix.layers[current_depth]
        cell_size = matrix.quadtree_size / layer.size
        
        offset_x = (self.width - matrix.quadtree_size) // 2
        offset_y = (self.height - matrix.quadtree_size) // 2

        for i, color_val in enumerate(layer.nodes):
            row, col = divmod(i, layer.size)
            cell_rect = pygame.Rect(
                offset_x + col * cell_size,
                offset_y + row * cell_size,
                cell_size,
                cell_size
            )

            if color_val > 0:
                r, g, b = (color_val >> 16) & 0xFF, (color_val >> 8) & 0xFF, color_val & 0xFF
                pygame.draw.rect(self.surface, (r, g, b), cell_rect)

            payload = matrix.payload_pool.get(f"{current_depth}:{i}")
            if payload:
                self._draw_payload(payload, cell_rect)
                if payload.last_run_meta and payload.last_run_meta.artifacts:
                    self._draw_artifact_preview(payload.last_run_meta, cell_rect, sidebar_width)

        self._draw_grid(matrix.quadtree_size, layer.size, cell_size, offset_x, offset_y)

    def _draw_grid(self, grid_size, num_cells, cell_size, ox, oy):
        """Helper to draw the grid lines over the cells."""
        for i in range(num_cells + 1):
            pos = i * cell_size
            pygame.draw.line(self.surface, COLORS["grid"], (ox + pos, oy), (ox + pos, oy + grid_size))
            pygame.draw.line(self.surface, COLORS["grid"], (ox, oy + pos), (ox + grid_size, oy + pos))

    def _draw_payload(self, payload: CellPayload, rect: pygame.Rect) -> None:
        """
        Dispatches to the correct rendering function based on payload type.
        """
        if payload.type == "text":
            self._draw_text_payload(payload.content, rect)
        elif payload.type == "code":
            self._draw_code_payload(payload.content, rect)
        elif payload.type == "image":
            self._draw_image_payload(payload.content, rect)

    def _draw_artifact_preview(self, meta: ExecMeta, cell_rect: pygame.Rect, sidebar_width: int):
        """Renders a preview of the first available artifact."""
        image_extensions = ['.png', '.jpg', '.jpeg', '.bmp', '.gif']
        
        # Prioritize image artifacts for thumbnails
        image_artifact = None
        for name, path in meta.artifacts.items():
            if any(name.lower().endswith(ext) for ext in image_extensions):
                image_artifact = (name, path)
                break
        
        preview_rect = cell_rect.inflate(-10, -10)
        preview_rect.bottom = cell_rect.bottom - 5
        preview_rect.right = cell_rect.right - 5
        
        if image_artifact:
            name, path = image_artifact
            if path in self.thumbnail_cache:
                thumb = self.thumbnail_cache[path]
            else:
                try:
                    img = pygame.image.load(path)
                    thumb = pygame.transform.smoothscale(img, preview_rect.size)
                    self.thumbnail_cache[path] = thumb
                except pygame.error as e:
                    print(f"Error loading artifact image: {e}")
                    return
            
            self.surface.blit(thumb, preview_rect)
            
            # Store screen-space rect for interaction
            screen_rect = preview_rect.move(sidebar_width, 0)
            self.artifact_rects[screen_rect] = path
        
        elif meta.artifacts:
            # Draw a generic file icon for non-image artifacts
            first_name, first_path = next(iter(meta.artifacts.items()))
            icon_font = self.fonts["header"]
            icon_surf = icon_font.render("📄", True, COLORS["text"])
            self.surface.blit(icon_surf, icon_surf.get_rect(center=preview_rect.center))
            
            screen_rect = preview_rect.move(sidebar_width, 0)
            self.artifact_rects[screen_rect] = first_path


    def _draw_text_payload(self, content: Dict[str, Any], rect: pygame.Rect) -> None:
        """Renders a text payload, centered in the cell."""
        text = content.get("text", "")
        color = content.get("color", COLORS["text"])
        font_size = int(rect.width * 0.3)
        font = pygame.font.Font(None, max(12, min(font_size, 48)))
        text_surf = font.render(text, True, color)
        self.surface.blit(text_surf, text_surf.get_rect(center=rect.center))

    def _draw_code_payload(self, content: Dict[str, Any], rect: pygame.Rect) -> None:
        """Renders a preview of a code payload."""
        if rect.width < 50:
            symbol_surf = self.fonts["mono_bold"].render("{;}", True, COLORS["text"])
            self.surface.blit(symbol_surf, symbol_surf.get_rect(center=rect.center))
            return
        
        code = content.get("code", "")
        lines = code.split('\n')
        font = self.fonts["mono"]
        line_height = font.get_height()
        
        old_clip = self.surface.get_clip()
        self.surface.set_clip(rect.inflate(-4, -4))
        
        for i, line in enumerate(lines):
            y_pos = rect.y + 5 + i * line_height
            if y_pos > rect.bottom - line_height:
                break
            line_surf = font.render(line, True, COLORS["text"])
            self.surface.blit(line_surf, (rect.x + 5, y_pos))
            
        self.surface.set_clip(old_clip)

    def _draw_image_payload(self, content: Dict[str, Any], rect: pygame.Rect) -> None:
        """Decodes and renders a base64 image payload."""
        b64_data = content.get("data")
        if not b64_data:
            return
            
        try:
            img_bytes = base64.b64decode(b64_data)
            img_file = io.BytesIO(img_bytes)
            pil_img = Image.open(img_file)
            
            img_surf = pygame.image.fromstring(pil_img.tobytes(), pil_img.size, pil_img.mode)
            
            scaled_surf = pygame.transform.scale(img_surf, (int(rect.width), int(rect.height)))
            self.surface.blit(scaled_surf, rect.topleft)
            
        except Exception as e:
            print(f"[Canvas] Error rendering image payload: {e}")
            error_surf = self.fonts["header"].render("!", True, COLORS["code"]["error"])
            self.surface.blit(error_surf, error_surf.get_rect(center=rect.center))
