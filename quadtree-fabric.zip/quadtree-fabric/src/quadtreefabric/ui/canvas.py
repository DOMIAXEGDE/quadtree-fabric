"""
ui/canvas.py

This module defines the Canvas class, which is responsible for all rendering
of the quadtree grid and its cell payloads. It encapsulates the drawing logic
for different payload types, such as text, code, and images.
"""

from __future__ import annotations
import base64
import io
import pygame
from PIL import Image
from typing import Any, Dict, Optional, Tuple

from ..config import COLORS
from ..data_models import Matrix, CellPayload


class Canvas:
    """
    Manages the rendering of the quadtree canvas.
    """

    def __init__(self, width: int, height: int, fonts: Dict[str, pygame.font.Font]):
        self.surface = pygame.Surface((width, height))
        self.width = width
        self.height = height
        self.fonts = fonts

    def get_cell_at_pos(
        self,
        pos: Tuple[int, int],
        matrix: Matrix,
        current_depth: int,
        sidebar_width: int
    ) -> Optional[Tuple[int, int]]:
        """
        Calculates which cell, if any, is at a given screen position.

        Args:
            pos: The (x, y) screen coordinates.
            matrix: The current Matrix data object.
            current_depth: The currently viewed depth level.
            sidebar_width: The width of the sidebar UI panel.

        Returns:
            A tuple of (depth, index) for the cell, or None if the position
            is outside the quadtree grid.
        """
        layer = matrix.layers[current_depth]
        cell_size = matrix.quadtree_size / layer.size
        
        offset_x = (self.width - matrix.quadtree_size) // 2 + sidebar_width
        offset_y = (self.height - matrix.quadtree_size) // 2

        rel_x = pos[0] - offset_x
        rel_y = pos[1] - offset_y

        if 0 <= rel_x < matrix.quadtree_size and 0 <= rel_y < matrix.quadtree_size:
            col = int(rel_x // cell_size)
            row = int(rel_y // cell_size)
            index = row * layer.size + col
            return (current_depth, index)
        
        return None

    def draw(self, matrix: Matrix, current_depth: int) -> None:
        """
        Renders the entire quadtree grid for the given context and depth.

        Args:
            matrix: The Matrix object to render.
            current_depth: The depth level to display.
        """
        self.surface.fill(COLORS["bg"])
        
        if not matrix:
            return

        layer = matrix.layers[current_depth]
        cell_size = matrix.quadtree_size / layer.size
        
        offset_x = (self.width - matrix.quadtree_size) // 2
        offset_y = (self.height - matrix.quadtree_size) // 2

        for i, color_val in enumerate(layer.nodes):
            row, col = divmod(i, layer.size)
            cell_rect = pygame.Rect(
                offset_x + col * cell_size,
                offset_y + row * cell_size,
                cell_size,
                cell_size
            )

            # Draw cell background color
            if color_val > 0:
                r, g, b = (color_val >> 16) & 0xFF, (color_val >> 8) & 0xFF, color_val & 0xFF
                pygame.draw.rect(self.surface, (r, g, b), cell_rect)

            # Draw cell payload
            payload = matrix.payload_pool.get(f"{current_depth}:{i}")
            if payload:
                self._draw_payload(payload, cell_rect)

        # Draw grid lines
        self._draw_grid(matrix.quadtree_size, layer.size, cell_size, offset_x, offset_y)

    def _draw_grid(self, grid_size, num_cells, cell_size, ox, oy):
        """Helper to draw the grid lines over the cells."""
        for i in range(num_cells + 1):
            pos = i * cell_size
            # Vertical lines
            pygame.draw.line(self.surface, COLORS["grid"], (ox + pos, oy), (ox + pos, oy + grid_size))
            # Horizontal lines
            pygame.draw.line(self.surface, COLORS["grid"], (ox, oy + pos), (ox + grid_size, oy + pos))

    def _draw_payload(self, payload: CellPayload, rect: pygame.Rect) -> None:
        """
        Dispatches to the correct rendering function based on payload type.
        """
        if payload.type == "text":
            self._draw_text_payload(payload.content, rect)
        elif payload.type == "code":
            self._draw_code_payload(payload.content, rect)
        elif payload.type == "image":
            self._draw_image_payload(payload.content, rect)

    def _draw_text_payload(self, content: Dict[str, Any], rect: pygame.Rect) -> None:
        """Renders a text payload, centered in the cell."""
        text = content.get("text", "")
        color = content.get("color", COLORS["text"])
        font_size = int(rect.width * 0.3)
        font = pygame.font.Font(None, max(12, min(font_size, 48))) # Use a system font
        text_surf = font.render(text, True, color)
        self.surface.blit(text_surf, text_surf.get_rect(center=rect.center))

    def _draw_code_payload(self, content: Dict[str, Any], rect: pygame.Rect) -> None:
        """Renders a preview of a code payload."""
        # For small cells, just show a symbol
        if rect.width < 50:
            symbol_surf = self.fonts["mono_bold"].render("{;}", True, COLORS["text"])
            self.surface.blit(symbol_surf, symbol_surf.get_rect(center=rect.center))
            return
        
        # For larger cells, show a snippet
        code = content.get("code", "")
        lines = code.split('\n')
        font = self.fonts["mono"]
        line_height = font.get_height()
        
        # Clip rendering to within the cell's bounds
        old_clip = self.surface.get_clip()
        self.surface.set_clip(rect.inflate(-4, -4))
        
        for i, line in enumerate(lines):
            y_pos = rect.y + 5 + i * line_height
            if y_pos > rect.bottom - line_height:
                break
            line_surf = font.render(line, True, COLORS["text"])
            self.surface.blit(line_surf, (rect.x + 5, y_pos))
            
        self.surface.set_clip(old_clip)

    def _draw_image_payload(self, content: Dict[str, Any], rect: pygame.Rect) -> None:
        """Decodes and renders a base64 image payload."""
        b64_data = content.get("data")
        if not b64_data:
            return
            
        try:
            img_bytes = base64.b64decode(b64_data)
            img_file = io.BytesIO(img_bytes)
            pil_img = Image.open(img_file)
            
            # Convert PIL image to Pygame surface
            img_surf = pygame.image.fromstring(pil_img.tobytes(), pil_img.size, pil_img.mode)
            
            # Scale to fit the cell and draw
            scaled_surf = pygame.transform.scale(img_surf, (int(rect.width), int(rect.height)))
            self.surface.blit(scaled_surf, rect.topleft)
            
        except Exception as e:
            print(f"[Canvas] Error rendering image payload: {e}")
            # Optionally, draw an error icon
            error_surf = self.fonts["header"].render("!", True, COLORS["code"]["error"])
            self.surface.blit(error_surf, error_surf.get_rect(center=rect.center))
