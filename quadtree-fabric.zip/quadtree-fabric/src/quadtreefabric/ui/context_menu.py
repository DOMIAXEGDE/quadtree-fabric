"""
ui/context_menu.py

This module defines the ContextMenu class, which provides a dynamic,
right-click menu for interacting with cells on the quadtree canvas.
"""

from __future__ import annotations
import pygame
from typing import Any, Callable, Dict, List, Optional, Tuple

from ..config import COLORS


class ContextMenu:
    """
    A context-sensitive menu that appears at a specific position, typically
    in response to a right-click event.
    """
    OPTION_HEIGHT = 30
    SEPARATOR = "---"

    def __init__(
        self,
        x: int, y: int,
        width: int,
        options: List[Tuple[str, Optional[Callable[[], Any]]]],
        fonts: Dict[str, pygame.font.Font]
    ):
        """
        Initializes the context menu.

        Args:
            x: The x-coordinate for the top-left corner of the menu.
            y: The y-coordinate for the top-left corner of the menu.
            width: The width of the menu.
            options: A list of tuples, where each tuple contains an option's
                     label and its associated callback action. A label of "---"
                     creates a visual separator.
            fonts: A dictionary of pre-loaded pygame fonts.
        """
        self.options = options
        self.fonts = fonts
        self.width = width
        self.height = len(options) * self.OPTION_HEIGHT
        self.rect = pygame.Rect(x, y, self.width, self.height)
        self.hovered_index: int = -1

    def draw(self, surface: pygame.Surface) -> None:
        """Renders the entire context menu to the given surface."""
        # Draw background and border
        pygame.draw.rect(surface, COLORS["surface"], self.rect, border_radius=4)
        pygame.draw.rect(surface, COLORS["accent"], self.rect, width=1, border_radius=4)

        # Draw each option
        for i, (label, _) in enumerate(self.options):
            option_rect = pygame.Rect(
                self.rect.x, self.rect.y + i * self.OPTION_HEIGHT,
                self.width, self.OPTION_HEIGHT
            )

            # Highlight the hovered option
            if i == self.hovered_index:
                pygame.draw.rect(surface, COLORS["bg"], option_rect, border_radius=2)

            if label == self.SEPARATOR:
                self._draw_separator(surface, option_rect)
            else:
                self._draw_option_text(surface, label, option_rect)

    def _draw_separator(self, surface: pygame.Surface, rect: pygame.Rect) -> None:
        """Draws a horizontal line for a separator."""
        start_pos = (rect.left + 5, rect.centery)
        end_pos = (rect.right - 5, rect.centery)
        pygame.draw.line(surface, COLORS["accent"], start_pos, end_pos, 1)

    def _draw_option_text(self, surface: pygame.Surface, label: str, rect: pygame.Rect) -> None:
        """Renders the text for a single menu option."""
        font = self.fonts["base"]
        text_surf = font.render(label, True, COLORS["text"])
        text_rect = text_surf.get_rect(midleft=(rect.left + 15, rect.centery))
        surface.blit(text_surf, text_rect)

    def _update_hover(self, pos: Tuple[int, int]) -> None:
        """Updates the index of the currently hovered option."""
        self.hovered_index = -1
        if self.rect.collidepoint(pos):
            relative_y = pos[1] - self.rect.y
            index = relative_y // self.OPTION_HEIGHT
            if 0 <= index < len(self.options):
                # Do not allow hovering over separators
                if self.options[index][0] != self.SEPARATOR:
                    self.hovered_index = index

    def handle_event(self, event: pygame.event.Event) -> Any:
        """
        Processes a single pygame event. If an option is clicked, its
        action is triggered.

        Returns:
            The result of the callback action if an option is clicked,
            otherwise False.
        """
        if event.type == pygame.MOUSEMOTION:
            self._update_hover(event.pos)
            return False

        if event.type == pygame.MOUSEBUTTONDOWN and event.button == 1:
            if self.rect.collidepoint(event.pos) and self.hovered_index != -1:
                _, action = self.options[self.hovered_index]
                if action:
                    return action()  # Execute the callback
        
        return False
