"""
config.py

This module contains the static configuration for the Quadtree Fabric application.
It defines screen dimensions, UI layout values, font specifications, and the
color palette used throughout the user interface.
"""

# --- Main Application Window ---
SCREEN_WIDTH_DEFAULT = 1280
SCREEN_HEIGHT_DEFAULT = 720

# --- UI Layout ---
SIDEBAR_WIDTH = 280
MAIN_WIDTH = SCREEN_WIDTH_DEFAULT - SIDEBAR_WIDTH

# --- Font Specifications ---
# Using dictionaries to group related font properties
FONTS = {
    "base": {"name": "sans-serif", "size": 14},
    "header": {"name": "sans-serif", "size": 20, "bold": True},
    "mono": {"name": "Courier New", "size": 12},
    "mono_bold": {"name": "Courier New", "size": 14, "bold": True},
}

# --- Color Palette ---
# A structured dictionary for easy access and theming
COLORS = {
    "primary": (75, 83, 32),        # Army Green
    "secondary": (189, 183, 107),  # Dark Khaki
    "accent": (108, 117, 125),     # Slate Gray
    "bg": (245, 245, 220),         # Beige
    "surface": (255, 255, 255),    # White
    "text": (51, 51, 51),         # Dark Gray
    "grid": (204, 204, 204),       # Grid lines
    "button_hover": (219, 213, 137), # Lighter version of secondary

    "code": {
        "bg": (247, 247, 240),      # Light Code Background
        "line_number": (144, 144, 144), # Line Number Gray
        "selection": (200, 200, 255), # Light blue for text selection
        "error": (200, 0, 0),         # Red for error messages/indicators
        "success": (0, 128, 0),       # Green for success messages/indicators
    }
}
